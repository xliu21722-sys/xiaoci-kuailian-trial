import Foundation
import AVFoundation

// A small, bundled macOS helper. JSON arrives on stdin; synthesized audio is
// returned as PCM WAV on stdout. It never receives credentials or uses a temp file.
let available = AVSpeechSynthesisVoice.speechVoices().filter { $0.language.hasPrefix("zh-CN") }
if CommandLine.arguments.contains("--list") {
    let rows = available.map { ["id":$0.identifier,"name":$0.name,"language":$0.language,"gender":String($0.gender.rawValue)] }
    FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:rows))
    exit(0)
}
guard let data=readLine()?.data(using:.utf8),
      let config=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],
      let text=config["text"] as? String, !text.isEmpty, text.count<=5000 else { exit(2) }
let name=config["voice"] as? String ?? "Tingting"
let selected=available.first { $0.name.localizedCaseInsensitiveContains(name) || $0.identifier.localizedCaseInsensitiveContains(name) }
guard let selected=selected else { FileHandle.standardError.write(Data("本机缺少所选中文声音。".utf8));exit(3) }
let utterance=AVSpeechUtterance(string:text)
utterance.voice=selected
utterance.rate=Float(config["rate"] as? Double ?? 0.48)
utterance.pitchMultiplier=Float(config["pitch"] as? Double ?? 1.0)
let synthesizer=AVSpeechSynthesizer()
var pcm=Data(),sampleRate:UInt32=22050,finished=false
func appendLE<T:FixedWidthInteger>(_ value:T,to data:inout Data) { var v=value.littleEndian;withUnsafeBytes(of:&v){data.append(contentsOf:$0)} }
func finish() {
    if finished {return};finished=true
    var wav=Data("RIFF".utf8);appendLE(UInt32(36+pcm.count),to:&wav)
    wav.append(Data("WAVEfmt ".utf8));appendLE(UInt32(16),to:&wav);appendLE(UInt16(1),to:&wav);appendLE(UInt16(1),to:&wav)
    appendLE(sampleRate,to:&wav);appendLE(sampleRate*2,to:&wav);appendLE(UInt16(2),to:&wav);appendLE(UInt16(16),to:&wav)
    wav.append(Data("data".utf8));appendLE(UInt32(pcm.count),to:&wav);wav.append(pcm)
    FileHandle.standardOutput.write(wav);exit(pcm.isEmpty ? 4:0)
}
synthesizer.write(utterance) { buffer in
    guard let buffer=buffer as? AVAudioPCMBuffer else{return}
    if buffer.frameLength==0 {finish();return}
    sampleRate=UInt32(buffer.format.sampleRate)
    if let samples=buffer.floatChannelData?[0] {
        for i in 0..<Int(buffer.frameLength) {appendLE(Int16(max(-32768,min(32767,Double(samples[i])*32767))),to:&pcm)}
    } else if let samples=buffer.int16ChannelData?[0] {
        for i in 0..<Int(buffer.frameLength) {appendLE(samples[i],to:&pcm)}
    }
}
DispatchQueue.main.asyncAfter(deadline:.now()+90) {exit(5)}
RunLoop.main.run()
