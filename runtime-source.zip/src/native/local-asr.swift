import Foundation
import Speech
import AVFoundation

// Local macOS 26 speech model only. PCM stays in pipes/memory; no credentials,
// expected-script prompts, network recognizer, temporary audio or text logs.
let outputLock=NSLock()
func emit(_ value:[String:Any]) {
    guard let bytes=try? JSONSerialization.data(withJSONObject:value) else{return}
    outputLock.lock();defer{outputLock.unlock()}
    FileHandle.standardOutput.write(bytes);FileHandle.standardOutput.write(Data([10]))
}
struct Piece:Sendable {let start:Int64;let end:Int64;let text:String}
struct Recognized:Sendable {let pieces:[Piece];let candidates:[String]}

// Blocking stdin reads must never occupy the executor delivering Speech results.
// Bound the queue to five seconds; fail instead of silently dropping microphone PCM.
func microphoneFrames() -> AsyncThrowingStream<Data,Error> {
    AsyncThrowingStream(bufferingPolicy:.bufferingOldest(50)) { continuation in
        Task.detached {
            do {
                var pending=Data()
                while let data=try FileHandle.standardInput.read(upToCount:3200),!data.isEmpty {
                    pending.append(data)
                    while pending.count>=3200 {
                        let frame=Data(pending.prefix(3200));pending.removeFirst(3200)
                        if case .dropped = continuation.yield(frame) {throw NSError(domain:"AudioBackpressure",code:1)}
                    }
                }
                if pending.count>=2 {
                    if case .dropped = continuation.yield(Data(pending.prefix(pending.count/2*2))) {throw NSError(domain:"AudioBackpressure",code:1)}
                }
                continuation.finish()
            } catch {continuation.finish(throwing:error)}
        }
    }
}

// An utterance can contain several internal final segments. Those are NOT
// independently scored: only silence/EOF closes this whole attempt.
final class Utterance {
    let analyzer:SpeechAnalyzer
    let continuation:AsyncStream<AnalyzerInput>.Continuation
    let results:Task<Recognized,Error>
    let format:AVAudioFormat
    let preview:Utterance?
    init(locale:Locale,format:AVAudioFormat,previewOnly:Bool=false) async throws {
        self.format=format
        // Low-latency output is display-only. The accurate stream decides the
        // final text, so speed does not downgrade negation/number checking.
        self.preview=previewOnly ? nil : try? await Utterance(locale:locale,format:format,previewOnly:true)
        let transcriber=SpeechTranscriber(locale:locale,transcriptionOptions:[],reportingOptions:previewOnly ? [.volatileResults,.fastResults]:[.volatileResults],attributeOptions:[.audioTimeRange])
        analyzer=SpeechAnalyzer(modules:[transcriber],options:SpeechAnalyzer.Options(priority:.userInitiated,modelRetention:.processLifetime))
        try await analyzer.prepareToAnalyze(in:format)
        let (stream,continuation)=AsyncStream<AnalyzerInput>.makeStream()
        self.continuation=continuation
        let showPreview=previewOnly || self.preview == nil
        results=Task {
            var pieces=[Piece](), seen=Set<String>(), candidates=[String]()
            for try await result in transcriber.results {
                let text=String(result.text.characters).trimmingCharacters(in:.whitespacesAndNewlines)
                guard !text.isEmpty else{continue}
                let start=Int64((result.range.start.seconds*16000).rounded())
                let end=Int64((CMTimeRangeGetEnd(result.range).seconds*16000).rounded())
                if result.isFinal {
                    let key="\(start):\(end)"
                    if !seen.contains(key) {seen.insert(key);pieces.append(Piece(start:start,end:end,text:text))}
                }
                let display=(pieces.map{$0.text} + (result.isFinal ? []:[text])).joined(separator:" ")
                if !result.isFinal && candidates.last != display {
                    candidates.append(display);if candidates.count>8 {candidates.removeFirst()}
                }
                if showPreview {emit(["type":"partial","text":display,"startSample":pieces.first?.start ?? start,"endSample":end])}
            }
            return Recognized(pieces:pieces,candidates:candidates)
        }
        try await analyzer.start(inputSequence:stream)
    }
    func feed(_ data:Data,at sample:Int64) {
        preview?.feed(data,at:sample)
        let count=data.count/2
        guard count>0 else{return}
        let buffer=AVAudioPCMBuffer(pcmFormat:format,frameCapacity:AVAudioFrameCount(count))!
        buffer.frameLength=AVAudioFrameCount(count)
        _ = data.withUnsafeBytes{memcpy(buffer.int16ChannelData![0],$0.baseAddress!,count*2)}
        continuation.yield(AnalyzerInput(buffer:buffer,bufferStartTime:CMTime(value:sample,timescale:16000)))
    }
    func cancel() async {
        continuation.finish();results.cancel();await analyzer.cancelAndFinishNow()
        _ = await results.result
    }
    func finish() async throws {
        continuation.finish()
        try await analyzer.finalizeAndFinishThroughEndOfInput()
        // Await consumption as well as analysis, so no final text can arrive after
        // the attempt boundary or be mistakenly scored in the next attempt.
        let recognized=try await results.value
        let pieces=recognized.pieces
        await preview?.cancel()
        guard let first=pieces.first,let last=pieces.last else{return}
        emit(["type":"final","text":pieces.map{$0.text}.joined(separator:" "),"startSample":first.start,"endSample":last.end,"candidates":recognized.candidates])
    }
}

@main struct LocalSpeech {
    static func main() async {
        do {
            guard SpeechTranscriber.isAvailable,
                  let locale=await SpeechTranscriber.supportedLocale(equivalentTo:Locale(identifier:"zh-CN")),
                  await SpeechTranscriber.installedLocales.contains(where:{$0.language.languageCode?.identifier == "zh" && $0.region?.identifier == "CN"}) else {
                emit(["type":"error","message":"这台 Mac 尚未安装中文本机识别资源。已停止，不会改用收费识别。"]);exit(2)
            }
            let format=AVAudioFormat(commonFormat:.pcmFormatInt16,sampleRate:16000,channels:1,interleaved:false)!
            var engine:Utterance?=try await Utterance(locale:locale,format:format)
            emit(["type":"ready","engine":"Apple SpeechTranscriber","locale":locale.identifier,"onDevice":true])
            if CommandLine.arguments.contains("--check") {return}
            var sample:Int64=0,lastVoice:Int64=0,preRoll=[(Data,Int64)]()
            var speaking=false,noise=0.0005
            // 100 ms input frames. The pre-roll keeps the beginning of quiet syllables.
            // A 0.7 s quiet gap closes a fragment; incomplete lines still wait in JS.
            for try await frame in microphoneFrames() {
                let count=frame.count/2
                guard count>0 else{continue}
                var energy=0.0
                frame.withUnsafeBytes { bytes in
                    for value in bytes.bindMemory(to:Int16.self) {let v=Double(value)/32768;energy+=v*v}
                }
                let rms=sqrt(energy/Double(count)),threshold=max(0.004,min(0.025,noise*3))
                let voiced=rms>=threshold
                if !voiced {noise=0.98*noise+0.02*rms}
                if voiced {lastVoice=sample+Int64(count)}
                if !speaking {
                    preRoll.append((frame,sample));if preRoll.count>4{preRoll.removeFirst()}
                    if voiced {
                        if engine == nil {engine=try await Utterance(locale:locale,format:format)}
                        for (audio,position) in preRoll {engine!.feed(audio,at:position)}
                        preRoll.removeAll();speaking=true
                        emit(["type":"speech-start"])
                    }
                } else {engine!.feed(frame,at:sample)}
                sample+=Int64(count)
                if speaking && sample-lastVoice>=11200 {
                    try await engine!.finish();engine=nil;speaking=false;preRoll.removeAll()
                }
            }
            if speaking {try await engine?.finish()}
            emit(["type":"done"])
        } catch {
            emit(["type":"error","message":"本机中文识别暂时无法运行。录音会保留；不会连接任何收费服务。"]);exit(3)
        }
    }
}
