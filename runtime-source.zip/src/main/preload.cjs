const { contextBridge, ipcRenderer } = require('electron');
const invoke = (name) => (...args) => ipcRenderer.invoke(name,...args);
const subscribe = name => callback => {
  const listener = (_event,data) => callback(data);
  ipcRenderer.on(name,listener);
  return () => ipcRenderer.removeListener(name,listener);
};
contextBridge.exposeInMainWorld('duici',Object.freeze({
  boot:invoke('boot'), importScript:invoke('import-script'), saveDraft:invoke('save-draft'),
  saveKey:invoke('save-key'), importFishConfig:invoke('import-fish-config'), clone:invoke('clone'), voices:invoke('voices'), saveVoice:invoke('save-voice'),
  synthesize:invoke('synthesize'), cancelSpeech:invoke('cancel-speech'),
  microphonePermission:invoke('microphone-permission'),
  asrStart:invoke('asr-start'), asrSend:(data)=>ipcRenderer.send('asr-send',data), asrClose:invoke('asr-close'),
  onASR:subscribe('asr-event'), onAudioError:subscribe('audio-error'), onCloseRequested:subscribe('close-requested'),
  newRecording:invoke('recording-new'), appendRecording:invoke('recording-append'),
  checkpoint:invoke('recording-checkpoint'), finishRecording:invoke('recording-finish'),
  history:invoke('history'), readSession:invoke('read-session'), exportRecording:invoke('recording-export'),
  closeWindow:invoke('close-window'),
}));
