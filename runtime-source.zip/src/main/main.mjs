import { app, BrowserWindow, ipcMain, dialog, safeStorage, systemPreferences, session, protocol, Menu, net } from 'electron';
import { mkdir, readFile, stat, copyFile } from 'node:fs/promises';
import { createReadStream, existsSync } from 'node:fs';
import { Readable } from 'node:stream';
import { join, basename, extname, resolve, sep } from 'node:path';
import { release as osRelease } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { RecordingStore, atomicJSON, requireId } from './store.mjs';
import { recoverLegacyReviewDraft } from '../core/workspace.mjs';
import { LocalRealtime } from '../providers/local-asr.mjs';
import { installNodeNetworkGuard, migrateSpeechSettings, speechSettings, isAllowedFishRequest, restrictedFishFetch } from './speech-policy.mjs';
import { FishProvider } from '../providers/fish.mjs';
import { LOCAL_VOICES, synthesizeLocal } from '../providers/local.mjs';

// Keep the existing Keychain service and data identity through the visible rename.
// Electron initializes macOS Safe Storage using app.getName() before ready.
app.setName('对词器');
// Honor Electron's explicit profile switch for isolated QA. Normal launches keep
// the original data identity and never migrate or overwrite another profile.
const explicitProfile=app.commandLine.getSwitchValue('user-data-dir');
app.setPath('userData',explicitProfile?resolve(explicitProfile):join(app.getPath('appData'),'对词器'));
const DISPLAY_NAME='小词快练';
installNodeNetworkGuard();

const ROOT = fileURLToPath(new URL('../../',import.meta.url));
const PORTABLE=existsSync(join(ROOT,'portable-dist/index.html'));
const APP_URL = PORTABLE?'xiaoci-app://app/index.html':pathToFileURL(join(ROOT,'src/renderer/index.html')).href;
protocol.registerSchemesAsPrivileged([{scheme:'duici-media',privileges:{standard:true,secure:true,stream:true,supportFetchAPI:true}},
  {scheme:'xiaoci-app',privileges:{standard:true,secure:true,stream:true,supportFetchAPI:true,corsEnabled:true}}]);
const nativeASR=process.platform==='darwin'&&process.arch==='arm64'&&parseInt(osRelease(),10)>=25;
const nativeVoice=process.platform==='darwin'&&process.arch==='arm64';
if(!app.requestSingleInstanceLock()){app.quit();process.exit(0);}
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.show();win.focus();}});
let win, store, directory, config = {voiceId:'',voiceName:'',emotion:'neutral'}, fishApiKey='';
let asrRequestGeneration=0;
let activeASR = null, asrToken = '', allowClose = false, activeRecordingId = null;
let speechControllers = new Map(), audioCache = new Map();

function fail(message) { throw new Error(message); }
function trusted(event) {
  if (!win || event.sender !== win.webContents || event.senderFrame?.url !== APP_URL) fail('无效的窗口请求。');
}
function handle(channel, fn) { ipcMain.handle(channel,async (event,...args)=>{ trusted(event); return fn(...args); }); }
function short(value, max=200) { return String(value ?? '').slice(0,max); }
function plainJSON(value,max=4_000_000) {
  const encoded = JSON.stringify(value);
  if (!encoded || encoded.length>max) fail('数据量过大，请只导入要练习的一场戏。');
  return JSON.parse(encoded);
}
function provider() {
  if(!fishApiKey)fail('请先连接 Fish Audio，或选择本机免费声音。');
  return new FishProvider({apiKey:fishApiKey,fetchImpl:(url,options)=>restrictedFishFetch(net.fetch,url,options)});
}
async function encryptKey(value){
  if(typeof safeStorage.isAsyncEncryptionAvailable==='function'){
    if(!await safeStorage.isAsyncEncryptionAvailable())fail('无法安全保存密钥。');
    return (await safeStorage.encryptStringAsync(value)).toString('base64');
  }
  if(!safeStorage.isEncryptionAvailable() || (process.platform==='linux' && safeStorage.getSelectedStorageBackend()==='basic_text'))fail('无法安全保存密钥。');
  return safeStorage.encryptString(value).toString('base64');
}
async function decodeKey(cipher){
  const b=Buffer.from(cipher,'base64');
  return typeof safeStorage.decryptStringAsync==='function'?(await safeStorage.decryptStringAsync(b)).result:safeStorage.decryptString(b);
}
async function connectFish(candidate) {
  const voices=await new FishProvider({apiKey:candidate,fetchImpl:(url,options)=>restrictedFishFetch(net.fetch,url,options)}).listVoices();
  const cipher=await encryptKey(candidate);
  fishApiKey=candidate;config.fishKeyCipher=cipher;config.provider='fish';
  await saveConfig();audioCache.clear();return {settings:settings(),voices:[...LOCAL_VOICES,...voices]};
}
function send(channel,data) { if (win && !win.isDestroyed()) win.webContents.send(channel,data); }
function settings() { return speechSettings(config,Boolean(fishApiKey)); }
async function saveConfig() { await atomicJSON(join(directory,'settings.json'),config); }
function closeASR() {
  ++asrRequestGeneration;asrToken='';
  const previous=activeASR; activeASR=null;
  previous?.close();
}
function cancelSpeech() {
  for (const controller of speechControllers.values()) controller.abort();
  speechControllers.clear();
}

async function installHandlers() {
  handle('boot',async()=>{
    let draft;
    try { draft=JSON.parse(await readFile(join(directory,'draft.json'),'utf8')); } catch { draft=null; }
    let recoveredOriginal=false;
    if(draft?.schemaVersion!==2 && / · 错句重练$/u.test(draft?.script?.name || '')){
      const recovered=recoverLegacyReviewDraft(draft,await store.list());
      if(recovered){
        // Preserve the old draft privately before repairing its mistaken overwrite.
        await copyFile(join(directory,'draft.json'),join(directory,'draft.before-review-fix.json'),1).catch(error=>{if(error.code!=='EEXIST')throw error;});
        await atomicJSON(join(directory,'draft.json'),recovered);draft=recovered;recoveredOriginal=true;
      }
    }
    return {settings:settings(),draft,recoveredOriginal,version:app.getVersion(),platform:process.platform,nativeASR,nativeVoice};
  });
  handle('save-draft',async draft=>{ await atomicJSON(join(directory,'draft.json'),plainJSON(draft)); return true; });
  handle('import-script',async()=>{
    const selected=await dialog.showOpenDialog(win,{title:'导入剧本',properties:['openFile'],filters:[{name:'剧本',extensions:['txt','docx','pdf']} ]});
    if (selected.canceled) return null;
    const path=selected.filePaths[0];
    const info=await stat(path);
    if (info.size>15*1024*1024) fail('文件超过 15 MB，请先分出要练习的一场戏。');
    if (!['.txt','.docx','.pdf'].includes(extname(path).toLowerCase())) fail('请选择 TXT、Word 或可复制文字的 PDF。');
    return {name:basename(path),bytes:new Uint8Array(await readFile(path))};
  });
  handle('import-fish-config',async()=>{
    if(activeRecordingId)fail('请先结束当前录音。');
    const source=join(app.getPath('downloads'),'克隆音和数字人','.env');
    let text;try{text=await readFile(source,'utf8');}catch{fail('没有找到本机项目配置，请在安全输入框填写 Fish Audio 密钥。');}
    const line=text.split(/\r?\n/).find(l=>/^\s*FISH_API_KEY\s*=/.test(l));
    const candidate=line?.slice(line.indexOf('=')+1).trim().replace(/^(["'])(.*)\1$/,'$2');
    if(!candidate || candidate.length<10 || candidate.length>1000)fail('本机项目中没有有效的 Fish Audio 密钥。');
    return connectFish(candidate);
  });
  handle('save-key',async key=>{
    if(activeRecordingId)fail('请先结束当前录音。');
    if(typeof key!=='string' || key.trim().length<10 || key.length>1000)fail('请输入有效的 Fish Audio 密钥。');
    return connectFish(key.trim());
  });
  handle('voices',async()=>[...LOCAL_VOICES,...await provider().listVoices()]);
  handle('save-voice',async value=>{
    if (value.voiceId!==undefined) {
      if(!/^[\w-]{1,200}$/.test(value.voiceId))fail('请选择有效的声音。');
      config.voiceId=value.voiceId;config.voiceName=short(value.voiceName,100);
    }
    if (value.emotion!==undefined) {
      if (!['neutral','natural','calm','happy','sad','angry','fearful','excited','whisper'].includes(value.emotion)) fail('情绪设置无效。');
      config.emotion=value.emotion;
    }
    await saveConfig(); return settings();
  });
  handle('clone',async ({authorized,name}={})=>{
    if (authorized!==true) fail('请先确认你有权使用这段音频来克隆声音。');
    if (activeRecordingId) fail('请结束当前练习后再导入声音。');
    const selected=await dialog.showOpenDialog(win,{title:'选择有授权的声音样本',properties:['openFile'],filters:[{name:'音频',extensions:['wav','mp3','m4a','flac','ogg','opus']}]});
    if (selected.canceled) return null;
    const file=selected.filePaths[0];
    if ((await stat(file)).size>25*1024*1024) fail('参考音频请控制在 25 MB 以内。');
    const clone=await provider().cloneVoice({bytes:await readFile(file),filename:basename(file),name:short(name || '我的对词声音',100)});
    if (!clone.requires_verification) {
      config.voiceId=clone.voice_id; config.voiceName=clone.name; await saveConfig();
    }
    return {clone,settings:settings()};
  });
  handle('synthesize',async ({text,voiceId,emotion,requestId}={})=>{
    if (typeof text!=='string' || text.length>10000) fail('台词长度无效。');
    const voice=voiceId || config.voiceId;
    const mood=emotion || config.emotion;
    const cacheKey=createHash('sha256').update(JSON.stringify([config.provider,voice,mood,text])).digest('hex');
    if (audioCache.has(cacheKey)) return audioCache.get(cacheKey);
    if (speechControllers.size>=4) fail('正在准备声音，请稍候。');
    const id=short(requestId || cacheKey,200), controller=new AbortController();
    speechControllers.set(id,controller);
    try {
      const options={voiceId:voice,emotion:mood,signal:controller.signal};
      const result=LOCAL_VOICES.some(v=>v.voice_id===voice)?await synthesizeLocal(text,options):await provider().synthesize(text,options);
      const audio={bytes:new Uint8Array(result.buffer),mime:result.mime};
      if (audioCache.size>=60) audioCache.delete(audioCache.keys().next().value);
      audioCache.set(cacheKey,audio); return audio;
    } finally { if (speechControllers.get(id)===controller) speechControllers.delete(id); }
  });
  handle('cancel-speech',()=>{cancelSpeech();return true;});
  handle('microphone-permission',async()=>{
    if (process.platform!=='darwin') return true;
    const status=systemPreferences.getMediaAccessStatus('microphone');
    if (status==='granted') return true;
    if (status==='denied' || status==='restricted') fail('麦克风权限未打开。请在 Mac“系统设置 → 隐私与安全性 → 麦克风”中允许“小词快练”。');
    return systemPreferences.askForMediaAccess('microphone');
  });
  handle('asr-start',async ({token}={})=>{
    if (!activeRecordingId) fail('请先开始录音。');
    closeASR();
    const captured=short(token,200);
    if (!captured) fail('语音会话无效。');
    const client=new LocalRealtime();
    asrToken=captured; activeASR=client;
    for (const type of ['partial','final','timestamps','speech-start']) client.on(type,event=>{
      if (activeASR===client && asrToken===captured) send('asr-event',{...event,type,token:captured});
    });
    client.on('error',error=>{
      if (activeASR===client) send('asr-event',{type:'error',token:captured,message:error.message,code:error.code});
    });
    client.on('closed',()=>{
      if (activeASR===client) send('asr-event',{type:'closed',token:captured,message:'本机识别已停止。你的录音已保留，可继续这一句。'});
    });
    await client.connect();
    if (activeASR!==client) fail('语音连接已取消。');
    return {token:captured};
  });
  ipcMain.on('asr-send',(event,payload)=>{
    try {
      trusted(event);
      if (!activeASR || payload?.token!==asrToken) return;
      const buffer=Buffer.from(payload.bytes);
      if (!buffer.length || buffer.length>32000 || buffer.length%2) return;
      activeASR.sendPCM(buffer);
    } catch { send('audio-error',{message:'发送语音失败，请暂停后重试。'}); }
  });
  handle('asr-close',async()=>{await closeASR();return true;});
  handle('recording-new',async metadata=>{
    if (activeRecordingId) fail('上一段录音尚未结束。');
    const record=await store.create(plainJSON(metadata)); activeRecordingId=record.id; return record;
  });
  handle('recording-append',async ({id,bytes})=>{
    if (id!==activeRecordingId) fail('录音会话已变化。');
    await store.append(id,bytes); return true;
  });
  handle('recording-checkpoint',({id,report})=>store.checkpoint(id,plainJSON(report,12_000_000)));
  handle('recording-finish',async ({id,report,status})=>{
    await closeASR();
    try { return await store.finish(id,plainJSON(report,12_000_000),status==='complete'?'complete':'stopped'); }
    finally { if (activeRecordingId===id) activeRecordingId=null; }
  });
  handle('history',()=>store.list());
  handle('read-session',id=>store.read(id));
  handle('recording-export',async id=>{
    const record=await store.read(id);
    const safeName=short(record.title,80).replace(/[\\/:*?"<>|]/g,'_');
    const choice=await dialog.showSaveDialog(win,{title:'导出练习录音',defaultPath:`${safeName}-对词录音.wav`,filters:[{name:'WAV 录音',extensions:['wav']}]});
    if (choice.canceled) return false;
    await store.export(id,choice.filePath); return true;
  });
  handle('close-window',async()=>{allowClose=true;win.close();return true;});
}

app.whenReady().then(async()=>{
  app.setAboutPanelOptions({applicationName:DISPLAY_NAME,applicationVersion:app.getVersion()});
  directory=app.getPath('userData'); await mkdir(directory,{recursive:true,mode:0o700});
  store=new RecordingStore(directory);
  try { config={...config,...JSON.parse(await readFile(join(directory,'settings.json'),'utf8'))}; } catch {}
  // Restore Fish voices while keeping all real-time recognition on this Mac.
  config=migrateSpeechSettings(config);
  if(config.fishKeyCipher)fishApiKey=await decodeKey(config.fishKeyCipher).catch(()=>'');
  await saveConfig();
  if(PORTABLE)protocol.handle('xiaoci-app',request=>{
    const url=new URL(request.url),base=resolve(ROOT,'portable-dist');
    if(url.hostname!=='app')return new Response('Not found',{status:404});
    let target;try{target=resolve(base,'.'+decodeURIComponent(url.pathname));}catch{return new Response('Invalid path',{status:400});}
    if(!target.startsWith(base+sep))return new Response('Not found',{status:404});
    return net.fetch(pathToFileURL(target).href);
  });
  session.defaultSession.webRequest.onBeforeRequest(
    {urls:['http://*/*','https://*/*','ws://*/*','wss://*/*']},
    (details,callback)=>callback({cancel:!isAllowedFishRequest(details.url,details.method)})
  );
  session.defaultSession.webRequest.onBeforeSendHeaders(
    {urls:['https://api.fish.audio/v1/tts*']},
    (details,callback)=>{const model=Object.entries(details.requestHeaders).find(([key])=>key.toLowerCase()==='model')?.[1];callback({cancel:model!=='s2.1-pro-free'});}
  );
  protocol.handle('duici-media',async request=>{
    try {
      const url=new URL(request.url);
      if (url.hostname!=='recording') return new Response('Not found',{status:404});
      const id=requireId(url.pathname.slice(1));
      const path=store.audioPath(id), info=await stat(path);
      const range=request.headers.get('range');
      let start=0,end=info.size-1,statusCode=200;
      if (range) {
        const match=/^bytes=(\d*)-(\d*)$/.exec(range);
        if (!match) return new Response(null,{status:416});
        if (!match[1]) start=Math.max(0,info.size-Number(match[2]));
        else start=Number(match[1]);
        if (match[1] && match[2]) end=Math.min(end,Number(match[2]));
        if (!Number.isFinite(start) || !Number.isFinite(end) || start>end || start>=info.size) return new Response(null,{status:416,headers:{'Content-Range':`bytes */${info.size}`}});
        statusCode=206;
      }
      const headers={'Content-Type':'audio/wav','Accept-Ranges':'bytes','Content-Length':String(end-start+1),'Cache-Control':'no-store'};
      if (statusCode===206) headers['Content-Range']=`bytes ${start}-${end}/${info.size}`;
      return new Response(Readable.toWeb(createReadStream(path,{start,end})),{status:statusCode,headers});
    } catch { return new Response('Not found',{status:404}); }
  });
  await installHandlers();
  win=new BrowserWindow({width:980,height:780,minWidth:780,minHeight:620,title:DISPLAY_NAME,backgroundColor:'#f4f2ed',
    show:false,webPreferences:{preload:join(ROOT,'src/main/preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
  session.defaultSession.setPermissionRequestHandler((contents,permission,callback,details)=>{
    callback(contents===win?.webContents && permission==='media' && !(details.mediaTypes || []).includes('video'));
  });
  session.defaultSession.setPermissionCheckHandler((contents,permission)=>contents===win?.webContents && permission==='media');
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',event=>event.preventDefault());
  win.on('close',event=>{
    if (activeRecordingId && !allowClose) { event.preventDefault();send('close-requested',{}); }
  });
  win.on('closed',()=>{win=null;});
  win.webContents.on('render-process-gone',async()=>{
    closeASR();cancelSpeech();
    await store.closeAll();activeRecordingId=null;allowClose=true;
    if(win && !win.isDestroyed())win.destroy();
  });
  win.once('ready-to-show',()=>win.show());
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {label:DISPLAY_NAME,submenu:[{label:`关于${DISPLAY_NAME}`,role:'about'}, {type:'separator'},{label:`隐藏${DISPLAY_NAME}`,role:'hide'},{role:'hideOthers'},{role:'unhide'}, {type:'separator'},{label:`退出${DISPLAY_NAME}`,role:'quit'}]},
    {label:'编辑',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},
    {label:'窗口',submenu:[{role:'minimize'},{role:'zoom'},{role:'front'}]},
    {label:'帮助',submenu:[{label:'本机识别免费 · Fish 配音和克隆',enabled:false}]}
  ]));
  await win.loadURL(APP_URL);
});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',event=>{
  if(activeRecordingId && !allowClose){event.preventDefault();send('close-requested',{});return;}
  cancelSpeech();closeASR();
});
