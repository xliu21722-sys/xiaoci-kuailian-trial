import { mkdir, readFile, rename, readdir, open, lstat, copyFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';

export const SAMPLE_RATE = 16000;
export const CHANNELS = 1;
const MAX_RECORDING_BYTES = 1_800_000_000;
const VALID_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function requireId(id) {
  if (typeof id !== 'string' || !VALID_ID.test(id)) throw new Error('练习记录不存在。');
  return id;
}
export function wavHeader(bytes, rate = SAMPLE_RATE, channels = CHANNELS) {
  if (!Number.isSafeInteger(bytes) || bytes < 0 || bytes > 0xffffffff - 36
    || !Number.isInteger(channels) || channels < 1 || channels > 32
    || bytes % (channels * 2) !== 0 || !Number.isInteger(rate) || rate < 1 || rate > 384000) {
    throw new Error('录音格式不正确。');
  }
  const h = Buffer.alloc(44);
  h.write('RIFF',0); h.writeUInt32LE(36 + bytes,4); h.write('WAVEfmt ',8);
  h.writeUInt32LE(16,16); h.writeUInt16LE(1,20); h.writeUInt16LE(channels,22);
  h.writeUInt32LE(rate,24); h.writeUInt32LE(rate * channels * 2,28);
  h.writeUInt16LE(channels * 2,32); h.writeUInt16LE(16,34);
  h.write('data',36); h.writeUInt32LE(bytes,40); return h;
}

async function writeAll(handle, buffer, position) {
  let written = 0;
  while (written < buffer.length) {
    const result = await handle.write(buffer, written, buffer.length - written, position + written);
    if (!result.bytesWritten) throw new Error('无法写入录音，请检查磁盘空间。');
    written += result.bytesWritten;
  }
}

export async function atomicJSON(path, data) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  const serialized = JSON.stringify(data, null, 2);
  let handle;
  try {
    handle = await open(temporary, 'wx', 0o600);
    await handle.writeFile(serialized);
    await handle.sync();
    await handle.close(); handle = null;
    await rename(temporary, path);
  } finally {
    if (handle) await handle.close().catch(() => {});
    await unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; });
  }
}

async function regularFile(path) {
  const file = await lstat(path).catch(error => { if (error.code === 'ENOENT') return null; throw error; });
  if (file && (!file.isFile() || file.isSymbolicLink())) throw new Error('练习记录路径不正确。');
  return file;
}

/**
 * PCM writes and checkpoints share one queue. Closing rejects new writes before
 * awaiting the queue. Recovery trusts the actual aligned PCM byte count and
 * repairs the WAV header, including an interrupted final chunk.
 */
export class RecordingStore {
  constructor(root) { this.root = root; this.active = new Map(); this.recoveries = new Map(); }
  directory(id) { return join(this.root, 'sessions', requireId(id)); }
  audioPath(id) { return join(this.directory(id), 'recording.wav'); }

  async _verifyDirectory(id) {
    for (const path of [join(this.root, 'sessions'), this.directory(id)]) {
      const entry = await lstat(path);
      if (!entry.isDirectory() || entry.isSymbolicLink()) throw new Error('练习记录路径不正确。');
    }
  }

  _enqueue(state, task) {
    const operation = state.queue.then(task);
    // The original operation rejects to its caller, while serialization remains
    // usable after an isolated metadata checkpoint failure.
    state.queue = operation.catch(() => {});
    return operation;
  }

  async create(metadata = {}) {
    const id = randomUUID();
    const directory = this.directory(id);
    const sessions = join(this.root, 'sessions');
    await mkdir(sessions, {recursive: true, mode: 0o700});
    const parent = await lstat(sessions);
    if (!parent.isDirectory() || parent.isSymbolicLink()) throw new Error('练习记录路径不正确。');
    await mkdir(directory, {mode: 0o700});
    const handle = await open(this.audioPath(id), 'wx', 0o600);
    try {
      await writeAll(handle, wavHeader(0), 0);
      const record = {id, title: metadata.title || '未命名剧本', myRole: metadata.myRole,
        startedAt: new Date().toISOString(), status: 'recording', script: structuredClone(metadata.script),
        voice: structuredClone(metadata.voice), practice: structuredClone(metadata.practice), report: null, durationSeconds: 0};
      await atomicJSON(join(directory, 'session.json'), record);
      this.active.set(id, {handle, bytes: 0, reservedBytes: 0, queue: Promise.resolve(), record,
        chunks: 0, error: null, closing: false, finishing: null});
      return structuredClone(record);
    } catch (error) {
      await handle.close().catch(() => {});
      throw error;
    }
  }

  append(id, pcm) {
    const state = this.active.get(requireId(id));
    if (!state || state.closing) return Promise.reject(new Error('录音已经结束。'));
    let buffer;
    try {
      // Copy ArrayBuffer storage before waiting in the queue; callers may reuse
      // their audio frame immediately after sending it to this process.
      if (pcm instanceof ArrayBuffer) buffer = Buffer.from(new Uint8Array(pcm));
      else if (ArrayBuffer.isView(pcm)) buffer = Buffer.from(new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength));
      else if (Array.isArray(pcm)) buffer = Buffer.from(pcm);
      else throw new Error('录音数据不完整。');
    } catch { return Promise.reject(new Error('录音数据不完整。')); }
    if (!buffer.length || buffer.length % 2 || buffer.length > 256 * 1024) return Promise.reject(new Error('录音数据不完整。'));
    if (state.reservedBytes + buffer.length > MAX_RECORDING_BYTES) return Promise.reject(new Error('单次录音已达到容量上限，请结束后继续新的一轮。'));
    state.reservedBytes += buffer.length;
    return this._enqueue(state, async () => {
      if (state.error) throw state.error;
      try {
        await writeAll(state.handle, buffer, 44 + state.bytes);
        state.bytes += buffer.length;
        state.chunks += 1;
        if (state.chunks % 10 === 0) await writeAll(state.handle, wavHeader(state.bytes), 0);
      } catch (error) { state.error = error; throw error; }
    });
  }

  checkpoint(id, report) {
    const state = this.active.get(requireId(id));
    if (!state || state.closing) return Promise.reject(new Error('当前录音已关闭。'));
    const snapshot = structuredClone(report);
    return this._enqueue(state, async () => {
      state.record.report = snapshot;
      state.record.durationSeconds = state.bytes / (SAMPLE_RATE * CHANNELS * 2);
      await atomicJSON(join(this.directory(id), 'session.json'), state.record);
      return true;
    });
  }

  finish(id, report, status = 'complete') {
    const state = this.active.get(requireId(id));
    if (!state) return this.read(id);
    if (state.finishing) return state.finishing;
    const finalReport = report === undefined || report === null ? null : structuredClone(report);
    state.closing = true;
    state.finishing = (async () => {
      await state.queue;
      let failure = state.error;
      try {
        const file = await state.handle.stat();
        state.bytes = Math.floor(Math.max(0, file.size - 44) / 2) * 2;
        await state.handle.truncate(44 + state.bytes);
        await writeAll(state.handle, wavHeader(state.bytes), 0);
        await state.handle.sync();
      } catch (error) { failure ??= error; }
      finally {
        await state.handle.close().catch(error => { failure ??= error; });
      }
      state.record.report = finalReport ?? state.record.report;
      state.record.status = failure ? 'interrupted' : status;
      state.record.finishedAt = new Date().toISOString();
      state.record.durationSeconds = state.bytes / (SAMPLE_RATE * CHANNELS * 2);
      if (failure) state.record.warning = '录音写入曾中断，已保留能恢复的部分。';
      try {
        await atomicJSON(join(this.directory(id), 'session.json'), state.record);
        return structuredClone(state.record);
      } finally {
        // Retain active membership until final metadata is saved, so a read
        // cannot race recovery metadata against this completed record.
        this.active.delete(id);
      }
    })();
    return state.finishing;
  }

  async _readStored(id) {
    await this._verifyDirectory(id);
    const metadataPath = join(this.directory(id), 'session.json');
    if (!await regularFile(metadataPath)) throw new Error('练习记录不存在。');
    const record = JSON.parse(await readFile(metadataPath, 'utf8'));
    if (record.id !== id) throw new Error('练习记录编号不一致。');
    let file = await regularFile(this.audioPath(id));
    let sealed = false;
    if (file) {
      const reader = await open(this.audioPath(id), 'r');
      try {
        const header = Buffer.alloc(44);
        const {bytesRead} = await reader.read(header, 0, 44, 0);
        sealed = bytesRead === 44 && header.toString('ascii', 0, 4) === 'RIFF'
          && header.toString('ascii', 8, 12) === 'WAVE'
          && header.toString('ascii', 36, 40) === 'data'
          && header.readUInt32LE(4) === file.size - 8
          && header.readUInt16LE(20) === 1 && header.readUInt16LE(22) === CHANNELS
          && header.readUInt32LE(24) === SAMPLE_RATE && header.readUInt16LE(34) === 16
          && header.readUInt32LE(40) === file.size - 44 && file.size % 2 === 0;
      } finally { await reader.close(); }
    }
    if (file && (record.status === 'recording' || !sealed)) {
      const size = Math.floor(Math.max(0, file.size - 44) / 2) * 2;
      const header = wavHeader(size);
      const handle = await open(this.audioPath(id), 'r+');
      try {
        await handle.truncate(44 + size);
        await writeAll(handle, header, 0);
        await handle.sync();
      } finally { await handle.close(); }
      record.status = 'interrupted';
      record.durationSeconds = size / (SAMPLE_RATE * CHANNELS * 2);
      record.warning ||= '上次录制意外中断，已恢复保存下来的录音。';
      await atomicJSON(metadataPath, record);
      file = await regularFile(this.audioPath(id));
    } else if (record.status === 'recording' && !file) {
      record.status = 'interrupted';
      record.durationSeconds = 0;
      record.warning = '上次录制意外中断，未找到录音文件，已保留复盘记录。';
      await atomicJSON(metadataPath, record);
    }
    return {...record, recordingAvailable: Boolean(file && file.size > 44)};
  }

  async read(id) {
    requireId(id);
    const state = this.active.get(id);
    if (state) {
      if (state.finishing) {
        const record = await state.finishing;
        return {...record, recordingAvailable: state.bytes > 0};
      }
      await state.queue;
      return {...structuredClone(state.record), durationSeconds: state.bytes / (SAMPLE_RATE * CHANNELS * 2),
        recordingAvailable: state.bytes > 0};
    }
    if (this.recoveries.has(id)) return this.recoveries.get(id);
    const operation = this._readStored(id);
    this.recoveries.set(id, operation);
    try { return await operation; } finally { this.recoveries.delete(id); }
  }

  async list() {
    await mkdir(join(this.root, 'sessions'), {recursive: true, mode: 0o700});
    const parent = await lstat(join(this.root, 'sessions'));
    if (!parent.isDirectory() || parent.isSymbolicLink()) throw new Error('练习记录路径不正确。');
    const entries = await readdir(join(this.root, 'sessions'), {withFileTypes: true});
    const records = [];
    for (const entry of entries) {
      if (!entry.isDirectory() || !VALID_ID.test(entry.name)) continue;
      try { records.push(await this.read(entry.name)); } catch { /* Leave unrelated/damaged folders untouched. */ }
    }
    return records.sort((a, b) => String(b.startedAt).localeCompare(String(a.startedAt)));
  }

  async export(id, destination) {
    const state = this.active.get(requireId(id));
    if (state && !state.closing) throw new Error('请先结束录制，再导出完整录音。');
    const record = await this.read(id);
    if (!record.recordingAvailable) throw new Error('这次练习没有可导出的录音。');
    await copyFile(this.audioPath(id), destination);
  }

  async closeAll() {
    for (const id of [...this.active.keys()]) {
      try { await this.finish(id, undefined, 'interrupted'); } catch { /* A prior valid checkpoint is retained. */ }
    }
  }
}
