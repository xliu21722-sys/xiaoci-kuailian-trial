import http from 'node:http';
import https from 'node:https';
import http2 from 'node:http2';
import net from 'node:net';
import {LOCAL_VOICES} from '../providers/local.mjs';

export const FREE_TTS_MODEL='s2.1-pro-free';
export const POLICY_MESSAGE='收费识别和收费配音接口已关闭。识别只在本机运行；Fish 配音只用免费模型。';
function reject(){throw new Error(POLICY_MESSAGE);}
// All Fish requests use the restricted Electron fetch path below. Node sockets,
// including the former paid ASR WebSocket, have no permitted network route.
export function installNodeNetworkGuard(){
  globalThis.fetch=async()=>reject();
  http.request=http.get=https.request=https.get=reject;
  http2.connect=reject;net.connect=net.createConnection=reject;net.Socket.prototype.connect=reject;
}
export function isAllowedFishRequest(value,method='GET') {
  try {
    const url=new URL(value);
    if(url.protocol!=='https:' || url.hostname!=='api.fish.audio' || url.port || url.username || url.password)return false;
    const verb=String(method).toUpperCase();
    return (url.pathname==='/model' && ['GET','POST'].includes(verb)) || (url.pathname==='/v1/tts' && verb==='POST');
  }catch{return false;}
}
export async function restrictedFishFetch(fetchImpl,url,options={}) {
  if(!isAllowedFishRequest(url,options.method))reject();
  if(new URL(url).pathname==='/v1/tts' && new Headers(options.headers).get('model')!==FREE_TTS_MODEL)reject();
  return fetchImpl(url,{...options,redirect:'error'});
}
export function migrateSpeechSettings(previous={}) {
  const config={...previous,voiceProfiles:{...previous.voiceProfiles}};
  // The temporary all-local build archived Fish selection; restore it once.
  const oldFish=(previous.offlineOnly || previous.provider==='local')?previous.voiceProfiles?.fish:null;
  if(oldFish?.voiceId)Object.assign(config,oldFish);
  if(!config.voiceId){config.voiceId=LOCAL_VOICES[0].voice_id;config.voiceName=LOCAL_VOICES[0].name;}
  return {...config,provider:'fish',offlineOnly:false,localRecognition:true,emotion:config.emotion || 'neutral'};
}
export function speechSettings(config,hasKey=false) {
  // No key ciphertext or unrelated old settings enter the renderer.
  return {provider:'fish',localRecognition:true,hasKey:Boolean(hasKey),voiceId:config.voiceId,voiceName:config.voiceName,emotion:config.emotion,localVoices:LOCAL_VOICES,ttsModel:FREE_TTS_MODEL};
}
