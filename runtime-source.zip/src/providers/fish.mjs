import { EventEmitter } from 'node:events';
import WebSocket from 'ws';
import { encode, decode } from '@msgpack/msgpack';
import { VoiceServiceError } from './elevenlabs.mjs';

const API='https://api.fish.audio';
// Explicitly pin the free tier. Never retry on a paid model.
export const FISH_TTS_MODEL='s2.1-pro-free';
export const FISH_PRESETS=Object.freeze([
  {voice_id:'fish_bright_female',name:'活力女生 · AI 免费配音',reference:'048222d36be842f199ec8ac71993dce4',direction:'[bright, cheerful and energetic]',speed:1.06,source:'金'},
  {voice_id:'fish_bright_male',name:'活力男生 · AI 免费配音',reference:'6f1ca7031e964896905e5a46c5b2da4c',direction:'[cheerful, energetic and confident]',speed:1.06,source:'专业本男声'},
  {voice_id:'fish_deep_male',name:'低沉男生 · AI 免费配音',reference:'3ebbc3083add43d68aef50815e561316',direction:'[calm, low and steady]',speed:.94,source:'沉稳男声'},
  {voice_id:'fish_announcer_female',name:'播音女生 · AI 免费配音',reference:'160ebd05eb704f5cb8a0878289faa8c4',direction:'[clear and composed professional narration]',speed:.98,source:'平静叙述女性'}
].map(v=>Object.freeze({...v,category:'AI 免费配音',requires_verification:false})));
const mood={neutral:'',natural:'',calm:'[calm]',happy:'[happy]',sad:'[sad]',angry:'[angry]',fearful:'[scared]',excited:'[excited]',whisper:'[whispering]'};
const hints={401:'Fish Audio 密钥无效，请重新连接。',402:'Fish Audio 账户额度不足。本工具已固定免费配音，不会改用收费模型；请检查平台权限和限制。',403:'这个声音或功能暂未向你的 Fish Audio 账户开放。',429:'Fish Audio 使用量或并发达到限制，请稍后再试。'};
function serviceError(status){return new VoiceServiceError(hints[status] || `Fish Audio 请求未完成（${status}），请稍后重试。`,{status,code:`http_${status}`});}
function key(value){if(typeof value!=='string' || !value.trim())throw new Error('请先连接 Fish Audio。');return value.trim();}
function bytes(value){if(value instanceof ArrayBuffer)return Buffer.from(value);if(ArrayBuffer.isView(value))return Buffer.from(value.buffer,value.byteOffset,value.byteLength);throw new Error('音频数据无效。');}
function voice(v,category){return {voice_id:v._id,name:v.title || '未命名声音',category,requires_verification:v.state!=='trained',state:v.state};}
export function cleanFishTranscript(text){return String(text || '').replace(/<\|speaker:\d+\|>/g,'').replace(/\[[^\]\r\n]{1,80}\]/g,'').trim();}

export class FishProvider {
  #key;#fetch;
  constructor({apiKey,fetchImpl=globalThis.fetch}={}){this.#key=key(apiKey);this.#fetch=fetchImpl;}
  async request(path,{body,signal,json=true,timeoutMs=90000}={}){
    const timeout=AbortSignal.timeout(timeoutMs),combined=signal?AbortSignal.any([signal,timeout]):timeout;
    try {
      const headers={Authorization:`Bearer ${this.#key}`};
      if(body && !(body instanceof FormData))headers['Content-Type']='application/json';
      if(path==='/v1/tts')headers.model=FISH_TTS_MODEL;
      const r=await this.#fetch(API+path,{method:body?'POST':'GET',body,headers,signal:combined,redirect:'error'});
      if(!r.ok)throw serviceError(r.status);
      if(json)return await r.json();
      const mime=(r.headers.get('content-type') || '').split(';')[0];
      const buffer=Buffer.from(await r.arrayBuffer());
      if(!buffer.length || !(mime.startsWith('audio/') || mime==='application/octet-stream'))throw new Error('无有效音频');
      return {buffer,mime:mime==='application/octet-stream'?'audio/mpeg':mime};
    } catch(error){
      if(signal?.aborted)throw new DOMException('已取消。','AbortError');
      if(error instanceof VoiceServiceError)throw error;
      if(timeout.aborted)throw new Error('Fish Audio 响应超时，请稍后重试。创建声音超时后请先刷新声音，避免重复上传。');
      throw new Error('无法连接 Fish Audio 或读取响应，请检查网络。');
    }
  }
  async listOwn({signal}={}){
    const all=[];
    for(let page=1;page<=20;page++){
      const d=await this.request(`/model?self=true&page_size=100&page_number=${page}`,{signal,timeoutMs:20000});
      if(!Array.isArray(d.items))throw new Error('Fish Audio 声音列表无效。');
      all.push(...d.items.map(v=>voice(v,'我的声音')));
      if(d.has_more===false || (d.has_more===undefined && d.items.length<100))return all;
    }
    throw new Error('声音列表过长，请稍后重试。');
  }
  async listVoices({signal}={}){
    const own=await this.listOwn({signal});
    // Listing public presets must not prevent access to the user's private voices.
    let publicVoices=[];
    try {
      const d=await this.request('/model?self=false&language=zh&page_size=30&page_number=1&licensed=true',{signal,timeoutMs:20000});
      publicVoices=(d.items || []).filter(v=>v.state==='trained').map(v=>voice(v,'现成声音'));
    }catch(error){if(signal?.aborted)throw error;}
    const result=new Map();
    for(const v of [...own,...publicVoices])if(!result.has(v.voice_id))result.set(v.voice_id,v);
    // A no-reference option is provided explicitly, not masqueraded as a stable cloned identity.
    return [...FISH_PRESETS,{voice_id:'fish_default',name:'平台默认声音（不克隆）',category:'现成声音',requires_verification:false},...result.values()];
  }
  async synthesize(text,{voiceId,emotion='neutral',signal}={}){
    if(typeof text!=='string' || !text.trim() || text.length>4900)throw new Error('请使用 1～4900 字的台词。');
    if(!Object.hasOwn(mood,emotion))throw new Error('情绪设置无效。');
    if(!/^[\w-]{1,200}$/.test(voiceId || ''))throw new Error('请先选择声音。');
    const preset=FISH_PRESETS.find(v=>v.voice_id===voiceId),direction=mood[emotion] || preset?.direction;
    const payload={text:direction?`${direction} ${text}`:text,format:'mp3',mp3_bitrate:128,sample_rate:44100};
    if(voiceId!=='fish_default')payload.reference_id=preset?.reference || voiceId;
    if(preset)payload.prosody={speed:preset.speed};
    return this.request('/v1/tts',{body:JSON.stringify(payload),signal,json:false});
  }
  async cloneVoice({bytes:input,filename,name,signal}={}){
    const b=bytes(input),label=String(name || '').trim(),extension=String(filename || '').split('.').pop().toLowerCase();
    const mime={mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',flac:'audio/flac',ogg:'audio/ogg',opus:'audio/ogg'}[extension];
    if(!b.length || b.length>25*1024*1024 || !mime)throw new Error('请选择 25 MB 以内的有效声音样本。');
    if(!label || label.length>100)throw new Error('请填写 1～100 字的声音名称。');
    const form=new FormData();
    for(const [k,v] of Object.entries({type:'tts',title:label,train_mode:'fast',visibility:'private',enhance_audio_quality:'true',generate_sample:'false'}))form.append(k,v);
    form.append('voices',new Blob([b],{type:mime}),`sample.${extension}`);
    const d=await this.request('/model',{body:form,signal,timeoutMs:120000});
    if(!d._id)throw new Error('未取得声音编号。请先刷新声音，避免重复创建。');
    return {voice_id:d._id,name:label,requires_verification:d.state!=='trained',state:d.state};
  }
}

// MessagePack wire protocol verified against the Fish documentation. Only
// committed user turns count as attempts. Drafts, eager ends and duplicated
// commits can never advance the script. Expected text is never sent to ASR.
export class FishRealtime extends EventEmitter {
  constructor({apiKey,WebSocketImpl=WebSocket,agent}={}){super();this.apiKey=key(apiKey);this.WS=WebSocketImpl;this.agent=agent;this.state='idle';this.seen=new Set();this.on('error',()=>{});}
  connect({timeoutMs=15000}={}){
    if(this.state!=='idle')throw new Error('语音连接已存在。');
    this.state='connecting';
    return new Promise((resolve,reject)=>{
      this.reject=reject;
      const ws=this.socket=new this.WS('wss://api.fish.audio/v1/asr/realtime',{headers:{Authorization:`Bearer ${this.apiKey}`,model:'transcribe-stream-1'},agent:this.agent,handshakeTimeout:timeoutMs,maxPayload:1024*1024});
      const current=()=>this.socket===ws && !['closed','error'].includes(this.state);
      this.timer=setTimeout(()=>this.fail(new Error('连接 Fish 实时识别超时。录音会保留，请稍后继续。')),timeoutMs);
      ws.on('open',()=>{if(current())ws.send(encode({type:'config',audio:{format:'pcm_s16le',sample_rate:16000,channels:1},turn_detection:{mode:'auto',eager:false,silence_timeout_ms:5000},results:{drafts:true,diarize:false,ignore_timestamps:false}}));});
      ws.on('message',data=>{
        if(!current())return;
        let m;try{m=decode(data);}catch{this.fail(new Error('Fish 识别响应格式无效。'));return;}
        if(m.type==='session_started'){
          if(this.state!=='connecting')return;
          clearTimeout(this.timer);this.state='ready';this.sessionId=m.session_id;this.reject=null;
          this.keepalive=setInterval(()=>this.send({type:'keepalive'}),10000);this.keepalive.unref?.();
          resolve({sessionId:this.sessionId});
        }else if(m.type==='draft' && Number.isInteger(m.turn_index) && !this.seen.has(m.turn_index)){
          this.emit('partial',{text:cleanFishTranscript(m.text),segment:m.turn_index+1,sessionId:this.sessionId});
        }else if(m.type==='committed'){
          if(!Number.isInteger(m.turn_index) || this.seen.has(m.turn_index))return;
          this.seen.add(m.turn_index);
          if(m.user_turn===false)return;
          // Degraded finals are explicitly unreliable. Pause instead of judging the actor.
          if(m.degraded){this.fail(new Error('这段识别结果不可靠，已暂停且保留录音。请继续后重说本句。'));return;}
          this.emit('final',{text:cleanFishTranscript(m.text),segment:m.turn_index+1,sessionId:this.sessionId});
        }else if(m.type==='error')this.fail(new Error('Fish 实时识别中断，请检查账户额度、权限或网络。已有录音会保留。'));
        else if(m.type==='session_done')this.fail(new Error('实时识别已结束。请继续当前台词。'));
      });
      ws.on('unexpected-response',(_req,res)=>{res.resume();this.fail(serviceError(res.statusCode));});
      ws.on('error',()=>{if(current())this.fail(new Error('Fish 实时识别网络连接失败，已有录音会保留。'));});
      ws.on('close',()=>{if(current())this.fail(new Error('Fish 实时识别连接已断开，已有录音会保留。'));});
    });
  }
  send(message){
    if(this.state!=='ready' || this.socket?.readyState!==1)return false;
    if(this.socket.bufferedAmount>2*1024*1024){this.fail(new Error('网络跟不上录音，已暂停并保留录音。'));return false;}
    try{this.socket.send(encode(message));return true;}catch{this.fail(new Error('发送语音失败，已保留录音。'));return false;}
  }
  sendPCM(pcm){const b=bytes(pcm);if(!b.length || b.length%2)return false;return this.send({type:'audio',data:new Uint8Array(b)});}
  fail(error){if(['closed','error'].includes(this.state))return;this.state='error';this.cleanup();this.reject?.(error);this.reject=null;this.emit('error',error);}
  cleanup(){clearTimeout(this.timer);clearInterval(this.keepalive);const ws=this.socket;this.socket=null;ws?.terminate?.();}
  close(){if(this.state==='closed')return;this.state='closed';this.cleanup();this.reject?.(new DOMException('已取消。','AbortError'));this.reject=null;}
}
