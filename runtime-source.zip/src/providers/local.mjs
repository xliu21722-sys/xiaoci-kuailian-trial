import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const LOCAL_VOICES=Object.freeze([
  {voice_id:'local_bright_female',name:'活力女生 · 本机免费',voice:'Tingting',rate:.54,pitch:1.12},
  {voice_id:'local_bright_male',name:'活力男生 · 本机免费',voice:'Eddy',rate:.52,pitch:1.06},
  {voice_id:'local_deep_male',name:'低沉男生 · 本机免费',voice:'Reed',rate:.43,pitch:.83},
  {voice_id:'local_announcer_female',name:'播音女生 · 本机免费',voice:'Tingting',rate:.46,pitch:.97}
].map(v=>Object.freeze({...v,category:'本机免费',requires_verification:false})));
export function synthesizeLocal(text,{voiceId,emotion='neutral',signal}={}){
  const v=LOCAL_VOICES.find(v=>v.voice_id===voiceId);
  if(!v || typeof text!=='string' || !text.trim() || text.length>4900)throw new Error('本机声音或台词无效。');
  const adjustment={happy:[.025,.04],sad:[-.035,-.04],angry:[.01,-.02],fearful:[-.015,.02]}[emotion] || [0,0];
  const executable=fileURLToPath(new URL('../native/local-voice',import.meta.url)).replace('/app.asar/','/app.asar.unpacked/');
  return new Promise((resolve,reject)=>{
    if(signal?.aborted){reject(new DOMException('已取消。','AbortError'));return;}
    const child=spawn(executable,[],{stdio:['pipe','pipe','pipe']});
    const chunks=[];let size=0,settled=false;
    const timer=setTimeout(()=>done(new Error('本机配音超时。')),95000);
    const onAbort=()=>done(new DOMException('已取消。','AbortError'));
    function done(error,result){if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',onAbort);if(error){child.kill();reject(error);}else resolve(result);}
    signal?.addEventListener('abort',onAbort,{once:true});
    child.on('error',()=>done(new Error('本机声音组件无法启动，请使用修复后的完整应用。')));
    child.stdout.on('data',b=>{size+=b.length;if(size>32*1024*1024)done(new Error('台词太长，请分段。'));else chunks.push(b);});
    child.stderr.resume(); // Framework diagnostics are not script or application logs.
    child.stdin.on('error',()=>done(new Error('本机声音组件已停止。')));
    child.on('close',code=>{const buffer=Buffer.concat(chunks);if(code!==0 || buffer.toString('ascii',0,4)!=='RIFF' || buffer.length<=44)done(new Error('无法生成本机声音，请检查中文系统声音是否已安装。'));else done(null,{buffer,mime:'audio/wav'});});
    child.stdin.end(JSON.stringify({text,voice:v.voice,rate:v.rate+adjustment[0],pitch:v.pitch+adjustment[1]})+'\n');
  });
}
