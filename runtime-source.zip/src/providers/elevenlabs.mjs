import { EventEmitter } from 'node:events';
import WebSocket from 'ws';

// Official API contracts checked 2026-10-22. Keep this module in the main process.
// https://elevenlabs.io/docs/api-reference/text-to-speech/convert
// https://elevenlabs.io/docs/api-reference/voices/ivc/create
// https://elevenlabs.io/docs/api-reference/speech-to-text/v-1-speech-to-text-realtime
const API = 'https://api.elevenlabs.io';
const REALTIME = 'wss://api.elevenlabs.io/v1/speech-to-text/realtime';
const SAMPLE_RATE = 16000;
const MAX_CLONE_BYTES = 25 * 1024 * 1024;
const MAX_PENDING_BYTES = 2 * 1024 * 1024;

export const EMOTIONS = Object.freeze([
  { id: 'neutral', label: '自然', tag: '' },
  { id: 'natural', label: '自然', tag: '' },
  { id: 'calm', label: '平静', tag: '[calm]' },
  { id: 'happy', label: '开心', tag: '[happy]' },
  { id: 'sad', label: '难过', tag: '[sad]' },
  { id: 'angry', label: '生气', tag: '[angry]' },
  { id: 'fearful', label: '紧张', tag: '[scared]' },
  { id: 'excited', label: '激动', tag: '[excited]' },
  { id: 'whisper', label: '轻声', tag: '[whisper]' },
].map(Object.freeze));

export class VoiceServiceError extends Error {
  constructor(message, { code = 'voice_service_error', status = null, retryable = false } = {}) {
    super(message);
    this.name = 'VoiceServiceError';
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}

function checkKey(value) {
  if (typeof value !== 'string' || !value.trim()) {
    throw new VoiceServiceError('请先在声音设置中填写 ElevenLabs API Key。', { code: 'missing_api_key' });
  }
  return value.trim();
}

function abortError() {
  return new DOMException('已取消。', 'AbortError');
}

function apiMessage(status, detail, key) {
  const raw = typeof detail === 'string' ? detail : detail?.message;
  const suffix = typeof raw === 'string' ? raw.split(key).join('[已隐藏]').slice(0, 350) : '';
  const messages = {
    401: '声音服务没有接受这个 API Key，请检查密钥。',
    403: '此账号或 API Key 没有使用该功能的权限，请检查 ElevenLabs 的权限及套餐。',
    429: '声音服务暂时达到用量或并发限制，请稍后重试并检查账号额度。',
  };
  return messages[status] || `声音服务请求失败（${status}）${suffix ? `：${suffix}` : '。'}`;
}

function toBuffer(bytes) {
  if (Buffer.isBuffer(bytes)) return bytes;
  if (bytes instanceof ArrayBuffer) return Buffer.from(bytes);
  if (ArrayBuffer.isView(bytes)) return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  throw new TypeError('音频必须是 Buffer、ArrayBuffer 或 TypedArray。');
}

/** REST methods. No key, script, audio, or response body is ever logged. */
export class ElevenLabsProvider {
  #apiKey;
  #fetch;

  constructor({ apiKey, fetchImpl = globalThis.fetch } = {}) {
    this.#apiKey = checkKey(apiKey);
    if (typeof fetchImpl !== 'function') throw new TypeError('fetch is required');
    this.#fetch = fetchImpl;
  }

  async #request(path, { method = 'GET', body, signal, timeoutMs = 90000, json = true } = {}) {
    if (signal?.aborted) throw abortError();
    const controller = new AbortController();
    const onAbort = () => controller.abort();
    signal?.addEventListener('abort', onAbort, { once: true });
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
    timer.unref?.();
    try {
      const headers = { 'xi-api-key': this.#apiKey };
      if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json';
      const response = await this.#fetch(`${API}${path}`, {
        method, headers, body, signal: controller.signal, redirect: 'error',
      });
      if (!response.ok) {
        let payload;
        try { payload = await response.json(); } catch { payload = null; }
        const detail = payload?.detail;
        throw new VoiceServiceError(apiMessage(response.status, detail, this.#apiKey), {
          code: typeof detail?.status === 'string' ? detail.status : `http_${response.status}`,
          status: response.status,
          retryable: response.status === 429 || response.status >= 500,
        });
      }
      if (json) {
        const result = await response.json();
        if (controller.signal.aborted) throw abortError();
        return result;
      }
      const mime = (response.headers.get('content-type') || 'audio/mpeg').split(';')[0];
      const buffer = Buffer.from(await response.arrayBuffer());
      if (controller.signal.aborted) throw abortError();
      if (!buffer.length || !(mime.startsWith('audio/') || mime === 'application/octet-stream')) {
        throw new VoiceServiceError('声音服务没有返回有效的音频。', { code: 'invalid_audio_response' });
      }
      return { buffer, mime: mime === 'application/octet-stream' ? 'audio/mpeg' : mime };
    } catch (error) {
      if (signal?.aborted) throw abortError();
      if (timedOut) throw new VoiceServiceError('声音服务响应超时，请检查网络后重试。', { code: 'timeout', retryable: true });
      if (error instanceof VoiceServiceError) throw error;
      throw new VoiceServiceError('无法连接声音服务，请检查网络或稍后重试。', { code: 'network_error', retryable: true });
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
  }

  /** Returns available account voices; it does not silently select an English voice. */
  async listVoices({ signal } = {}) {
    const voices = new Map();
    const seenTokens = new Set();
    let nextToken;
    for (let page = 0; page < 20; page += 1) {
      const query = new URLSearchParams({ page_size: '100' });
      if (nextToken) query.set('next_page_token', nextToken);
      const data = await this.#request(`/v2/voices?${query}`, { signal, timeoutMs: 20000 });
      if (!Array.isArray(data.voices)) throw new VoiceServiceError('无法读取声音列表。', { code: 'invalid_voice_list' });
      for (const voice of data.voices) {
        if (!voice?.voice_id) continue;
        voices.set(voice.voice_id, {
          voice_id: voice.voice_id, name: voice.name || '未命名声音',
          category: voice.category || '', labels: voice.labels || {},
          preview_url: voice.preview_url || null,
          verified_languages: voice.verified_languages || [],
          requires_verification: Boolean(voice.voice_verification?.requires_verification && !voice.voice_verification?.is_verified),
        });
      }
      if (!data.has_more) return [...voices.values()];
      nextToken = data.next_page_token;
      if (!nextToken || seenTokens.has(nextToken)) break;
      seenTokens.add(nextToken);
    }
    throw new VoiceServiceError('声音列表分页异常，请稍后重试。', { code: 'voice_list_pagination' });
  }

  /** Generates one unchanged script line with an optional auditory direction tag. */
  async synthesize(text, { voiceId, emotion = 'natural', signal } = {}) {
    if (typeof text !== 'string' || !text.trim()) throw new TypeError('台词不能为空。');
    if (typeof voiceId !== 'string' || !voiceId.trim()) throw new TypeError('请先选择对词声音。');
    const setting = EMOTIONS.find(item => item.id === emotion);
    if (!setting) throw new TypeError('不支持的情绪。');
    const input = setting.tag ? `${setting.tag} ${text}` : text;
    if ([...input].length > 4900) throw new TypeError('单条台词过长，请将这段台词分为几个自然段。');
    return this.#request(`/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`, {
      method: 'POST', signal, json: false,
      body: JSON.stringify({ text: input, model_id: 'eleven_v3', language_code: 'zh', voice_settings: { stability: 0.5 } }),
    });
  }

  /** The caller obtains consent and reads the file. This method only uploads the supplied bytes. */
  async cloneVoice({ bytes, filename, name, signal } = {}) {
    const buffer = toBuffer(bytes);
    if (!buffer.length || buffer.length > MAX_CLONE_BYTES) throw new TypeError('请选择不超过 25 MB 的有效参考音频。');
    const safeFilename = String(filename || 'voice.wav').split(/[\\/]/).pop();
    const extension = safeFilename.split('.').pop().toLowerCase();
    const mime = { mp3: 'audio/mpeg', wav: 'audio/wav', m4a: 'audio/mp4', flac: 'audio/flac', ogg: 'audio/ogg' }[extension];
    if (!mime) throw new TypeError('参考音频请使用 MP3、WAV、M4A、FLAC 或 OGG。');
    const label = String(name || '').trim();
    if (!label || label.length > 100) throw new TypeError('请为声音填写 1～100 字的名称。');
    const form = new FormData();
    form.append('name', label);
    form.append('files', new Blob([buffer], { type: mime }), safeFilename);
    // Automatic denoising can hurt clean samples; leave it disabled.
    form.append('remove_background_noise', 'false');
    const data = await this.#request('/v1/voices/add', { method: 'POST', body: form, signal, timeoutMs: 120000 });
    if (typeof data.voice_id !== 'string' || !data.voice_id) {
      throw new VoiceServiceError('声音服务没有返回克隆声音编号。', { code: 'invalid_clone_response' });
    }
    return { voice_id: data.voice_id, requires_verification: Boolean(data.requires_verification), name: label };
  }
}

const SERVER_ERRORS = new Set([
  'auth_error', 'quota_exceeded', 'transcriber_error', 'input_error', 'invalid_request', 'error',
  'commit_throttled', 'unaccepted_terms', 'rate_limited', 'queue_overflow', 'resource_exhausted',
  'session_time_limit_exceeded', 'chunk_size_exceeded', 'insufficient_audio_activity',
]);
const ERROR_MESSAGES = {
  auth_error: '语音识别没有接受这个 API Key，请检查密钥。',
  quota_exceeded: '语音服务额度不足，请检查 ElevenLabs 账号。',
  unaccepted_terms: '请先登录 ElevenLabs 控制台，接受 Scribe 语音识别的服务条款。',
  rate_limited: '语音识别请求过于频繁，请稍后重新开始。',
  insufficient_audio_activity: '语音识别因较长时间没有收到声音而断开，请重新开始这句。',
  session_time_limit_exceeded: '本次语音连接已达到时长限制，请重新连接后继续。',
};

/**
 * Sends 16 kHz, mono, signed 16-bit little-endian PCM (no WAV header).
 * connect() waits for session_started, not merely the WebSocket open event.
 * final is emitted ONLY for committed_transcript. Delayed timestamp events never
 * emit a second final. Do not pass the expected script as transcription context.
 * No automatic reconnect: caller pauses rehearsal so stale audio cannot advance it.
 */
export class ElevenLabsRealtime extends EventEmitter {
  #apiKey;
  #WebSocket;
  #socket = null;
  #generation = 0;
  #pending = null;
  #connectionTimer = null;
  #abortCleanup = null;
  #segment = 0;

  constructor({ apiKey, WebSocketImpl = WebSocket } = {}) {
    super();
    this.#apiKey = checkKey(apiKey);
    this.#WebSocket = WebSocketImpl;
    this.state = 'idle';
    this.sessionId = null;
    this.connectionId = 0;
    this.sampleRate = SAMPLE_RATE;
    // EventEmitter otherwise throws if the caller has already removed its error listener.
    this.on('error', () => {});
  }

  async connect({ signal, commitStrategy = 'vad', silenceSeconds = 1.2, timeoutMs = 15000 } = {}) {
    if (this.state === 'connecting' || this.state === 'ready') throw new Error('语音识别已经连接或正在连接。');
    if (!['vad', 'manual'].includes(commitStrategy)) throw new TypeError('commitStrategy must be vad or manual');
    if (!(silenceSeconds >= 0.3 && silenceSeconds <= 3)) throw new RangeError('silenceSeconds must be 0.3–3');
    if (signal?.aborted) throw abortError();
    const generation = ++this.#generation;
    this.connectionId = generation;
    this.state = 'connecting';
    this.sessionId = null;
    this.#segment = 0;
    const query = new URLSearchParams({
      model_id: 'scribe_v2_realtime', audio_format: 'pcm_16000', language_code: 'zh',
      commit_strategy: commitStrategy, include_timestamps: 'true', no_verbatim: 'false',
      keepalive_interval_ms: '5000',
    });
    if (commitStrategy === 'vad') {
      query.set('vad_silence_threshold_secs', String(silenceSeconds));
      query.set('vad_threshold', '0.4');
      query.set('min_speech_duration_ms', '100');
      query.set('min_silence_duration_ms', '100');
    }
    const pending = new Promise((resolve, reject) => { this.#pending = { resolve, reject }; });
    let socket;
    try {
      socket = new this.#WebSocket(`${REALTIME}?${query}`, {
        headers: { 'xi-api-key': this.#apiKey }, handshakeTimeout: timeoutMs, maxPayload: 1024 * 1024,
      });
      this.#socket = socket;
    } catch {
      this.#fail(new VoiceServiceError('无法创建语音连接。', { code: 'connection_error', retryable: true }));
      return pending;
    }
    const current = () => this.#generation === generation && this.#socket === socket;
    socket.on('message', data => {
      if (!current()) return;
      let message;
      try { message = JSON.parse(data.toString()); }
      catch { this.#fail(new VoiceServiceError('语音服务返回了无法读取的数据。', { code: 'invalid_response' })); return; }
      const type = message.message_type;
      if (type === 'session_started') {
        if (this.state !== 'connecting') return;
        this.sessionId = message.session_id || null;
        this.state = 'ready';
        this.#clearConnectionTimer();
        const ready = { sessionId: this.sessionId, connectionId: generation, config: message.config || {} };
        this.#pending?.resolve(ready);
        this.#pending = null;
        this.emit('ready', ready);
      } else if (type === 'partial_transcript') {
        this.emit('partial', this.#event({ text: String(message.text || ''), segment: this.#segment + 1 }));
      } else if (type === 'committed_transcript') {
        this.#segment += 1;
        this.emit('final', this.#event({ text: String(message.text || ''), segment: this.#segment }));
      } else if (type === 'committed_transcript_with_timestamps') {
        // Use text/timestamps to associate this with the prior final if desired;
        // never assume arrival timing is a new spoken attempt.
        this.emit('timestamps', this.#event({ text: String(message.text || ''), words: message.words || [], languageCode: message.language_code || null }));
      } else if (type === 'warning') {
        this.emit('warning', this.#event({ message: String(message.warning || '').split(this.#apiKey).join('[已隐藏]').slice(0, 500) }));
      } else if (SERVER_ERRORS.has(type) || message.error) {
        this.#fail(new VoiceServiceError(ERROR_MESSAGES[type] || '语音识别连接中断，请重新连接后继续。', {
          code: SERVER_ERRORS.has(type) ? type : 'transcriber_error',
          retryable: !['auth_error', 'quota_exceeded', 'unaccepted_terms', 'invalid_request', 'input_error'].includes(type),
        }));
      }
    });
    socket.on('error', () => {
      if (current()) this.#fail(new VoiceServiceError('语音识别网络连接失败，请检查网络后重试。', { code: 'network_error', retryable: true }));
    });
    socket.on('close', (code) => {
      if (!current()) return;
      if (this.state !== 'closed' && this.state !== 'error') {
        this.#fail(new VoiceServiceError('语音识别连接已断开，请重新连接后继续。', { code: 'connection_closed', retryable: true }));
      }
    });
    this.#connectionTimer = setTimeout(() => {
      if (current() && this.state === 'connecting') this.#fail(new VoiceServiceError('连接语音识别超时，请检查网络后重试。', { code: 'timeout', retryable: true }));
    }, timeoutMs);
    this.#connectionTimer.unref?.();
    if (signal) {
      const onAbort = () => this.close();
      signal.addEventListener('abort', onAbort, { once: true });
      this.#abortCleanup = () => signal.removeEventListener('abort', onAbort);
      if (signal.aborted) this.close();
    }
    return pending;
  }

  #event(fields) { return { ...fields, sessionId: this.sessionId, connectionId: this.connectionId }; }

  #clearConnectionTimer() {
    if (this.#connectionTimer) clearTimeout(this.#connectionTimer);
    this.#connectionTimer = null;
  }

  #fail(error) {
    if (this.state === 'error' || this.state === 'closed') return;
    this.state = 'error';
    this.#clearConnectionTimer();
    this.#abortCleanup?.();
    this.#abortCleanup = null;
    this.#pending?.reject(error);
    this.#pending = null;
    const socket = this.#socket;
    this.#socket = null;
    if (socket) socket.terminate?.();
    this.emit('error', error);
    this.emit('closed', this.#event({ reason: error.code }));
  }

  #send(message) {
    const socket = this.#socket;
    if (this.state !== 'ready' || !socket || socket.readyState !== 1) return false;
    if (socket.bufferedAmount > MAX_PENDING_BYTES) {
      this.#fail(new VoiceServiceError('网络发送跟不上录音，请检查网络后重新连接。', { code: 'audio_backpressure', retryable: true }));
      return false;
    }
    try {
      socket.send(JSON.stringify(message), error => {
        if (error && this.#socket === socket) this.#fail(new VoiceServiceError('发送实时声音失败，请重新连接。', { code: 'audio_send_failed', retryable: true }));
      });
      return true;
    } catch {
      this.#fail(new VoiceServiceError('发送实时声音失败，请重新连接。', { code: 'audio_send_failed', retryable: true }));
      return false;
    }
  }

  /** Returns false when disconnected. Audio must be resampled by the caller. */
  sendPCM(bytes) {
    const buffer = toBuffer(bytes);
    if (!buffer.length) return false;
    if (buffer.length % 2 || buffer.length > 128000) throw new RangeError('PCM 必须是 16 位单声道，每个分块不超过 4 秒。');
    return this.#send({ message_type: 'input_audio_chunk', audio_base_64: buffer.toString('base64'), sample_rate: SAMPLE_RATE, commit: false });
  }

  /** Finalizes buffered audio; it does not close the connection or fabricate a result. */
  commit() {
    return this.#send({ message_type: 'input_audio_chunk', audio_base_64: '', sample_rate: SAMPLE_RATE, commit: true });
  }

  /** Immediate cancel: late transcripts are ignored. Call commit first if a final is wanted. */
  close() {
    if (this.state === 'closed') return;
    this.state = 'closed';
    ++this.#generation;
    this.#clearConnectionTimer();
    this.#abortCleanup?.();
    this.#abortCleanup = null;
    this.#pending?.reject(abortError());
    this.#pending = null;
    const socket = this.#socket;
    this.#socket = null;
    if (socket?.readyState === 1) {
      socket.close(1000, 'Rehearsal stopped');
      const timer = setTimeout(() => socket.terminate?.(), 1000);
      timer.unref?.();
    } else socket?.terminate?.();
    this.emit('closed', this.#event({ reason: 'cancelled' }));
  }
}
