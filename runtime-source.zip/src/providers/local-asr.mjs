import {EventEmitter} from 'node:events';
import {spawn} from 'node:child_process';
import {StringDecoder} from 'node:string_decoder';
import {fileURLToPath} from 'node:url';

const executable=fileURLToPath(new URL('../native/local-asr',import.meta.url)).replace('/app.asar/','/app.asar.unpacked/');

// Persistent PCM pipe, not a web service. stdout contains only local ASR events.
export class LocalRealtime extends EventEmitter {
  constructor({spawnImpl=spawn}={}) {super();this.spawn=spawnImpl;this.state='idle';this.pending='';this.decoder=new StringDecoder('utf8');this.segment=0;this.lastFinalEnd=-1;this.seen=new Set();this.on('error',()=>{});}
  connect({timeoutMs=25000}={}) {
    if(this.state!=='idle')throw new Error('本机识别已经启动。');
    this.state='connecting';
    return new Promise((resolve,reject)=>{
      this.resolve=resolve;this.reject=reject;
      const child=this.child=this.spawn(executable,[],{stdio:['pipe','pipe','pipe']});
      this.timer=setTimeout(()=>this.fail('本机识别准备超时。请暂停后继续；不会改用云端服务。'),timeoutMs);
      child.on('error',()=>this.fail('本机识别组件无法启动，请使用完整的免费版应用。'));
      child.stderr.resume();
      child.stdin.on('error',()=>this.fail('本机识别输入已停止，已有录音会保留。'));
      child.stdout.on('data',chunk=>{
        if(this.child!==child || ['closed','error'].includes(this.state))return;
        this.pending+=this.decoder.write(chunk);
        if(this.pending.length>256*1024){this.fail('本机识别响应异常，已有录音会保留。');return;}
        let end;
        while((end=this.pending.indexOf('\n'))>=0){const line=this.pending.slice(0,end);this.pending=this.pending.slice(end+1);if(!line)continue;try{this.receive(JSON.parse(line));}catch{this.fail('本机识别响应不完整，已有录音会保留。');}}
      });
      child.on('close',()=>{if(this.child===child && !['closed','error'].includes(this.state))this.fail('本机识别已停止，已有录音会保留。');});
    });
  }
  receive(m) {
    if(m.type==='ready') {
      if(this.state!=='connecting')return;
      if(m.onDevice!==true){this.fail('识别没有确认在本机运行，已停止。');return;}
      clearTimeout(this.timer);this.state='ready';this.reject=null;this.resolve?.({onDevice:true});this.resolve=null;return;
    }
    if(m.type==='error'){this.fail(typeof m.message==='string'?m.message:'本机识别暂不可用。');return;}
    if(this.state==='ready'&&m.type==='speech-start'){this.emit('speech-start',{});return;}
    if(this.state!=='ready' || !['partial','final'].includes(m.type))return;
    const start=Number(m.startSample),end=Number(m.endSample);
    if(!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start<0 || end<start || typeof m.text!=='string')return;
    if(end<=this.lastFinalEnd)return;
    const text=m.text.trim();if(!text)return;
    if(m.type==='partial'){this.emit('partial',{text,segment:this.segment+1});return;}
    const id=`${start}:${end}`;
    if(this.seen.has(id))return;
    // Reject overlapping/revised final ranges instead of scoring them again.
    if(start<this.lastFinalEnd){this.fail('本机识别出现重叠结果，已暂停。请继续后重说本句；不会重复计错。');return;}
    this.seen.add(id);this.lastFinalEnd=end;
    const candidates=(Array.isArray(m.candidates)?m.candidates:[]).slice(-12).filter(t=>typeof t==='string'&&t.length<=8000);
    this.emit('final',{text,segment:++this.segment,...(candidates.length?{candidates}:{})});
  }
  sendPCM(pcm) {
    if(this.state!=='ready' || !this.child)return false;
    const b=Buffer.isBuffer(pcm)?pcm:Buffer.from(pcm.buffer || pcm,pcm.byteOffset || 0,pcm.byteLength);
    if(!b.length || b.length%2)return false;
    if(this.child.stdin.writableLength>32000*5){this.fail('本机识别暂时跟不上，已暂停并保留录音。');return false;}
    try{return this.child.stdin.write(b);}catch{this.fail('本机识别输入中断。');return false;}
  }
  fail(message) {if(['closed','error'].includes(this.state))return;this.state='error';const error=new Error(message);this.cleanup();this.reject?.(error);this.reject=null;this.resolve=null;this.emit('error',error);}
  cleanup(){clearTimeout(this.timer);const child=this.child;this.child=null;child?.kill();}
  close(){if(this.state==='closed')return;this.state='closed';this.cleanup();this.reject?.(new DOMException('已取消。','AbortError'));this.reject=null;this.resolve=null;}
}
