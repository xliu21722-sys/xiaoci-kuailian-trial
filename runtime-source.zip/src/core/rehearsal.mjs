/**
 * Deterministic rehearsal logic. No microphone, network, filesystem or UI APIs.
 *
 * A provider's interim ASR text is NEVER evidence of an actor's mistake.
 * `receive({isFinal:true})` means an ended utterance, unless
 * `endOfUtterance:false` explicitly marks an intermediate final ASR segment.
 * Provider adapters must send a turnId captured when their listening turn began.
 */
import {makeHint, cueRange} from './script.mjs';
import {comparePronunciation,recoverWeakParticle} from './phonetics.mjs';

const DIGITS = new Map(Object.entries({'零':0, '〇':0, '○':0, '一':1, '二':2, '两':2, '兩':2, '三':3, '四':4, '五':5, '六':6, '七':7, '八':8, '九':9}));
const SMALL_UNITS = new Map(Object.entries({十:10, 百:100, 千:1000}));
const BIG_UNITS = new Map(Object.entries({万:10000, 萬:10000, 亿:100000000, 億:100000000}));
const NUMERAL_RUN = /[负負]?[零〇○一二两兩三四五六七八九十百千万萬亿億]+(?:点[零〇○一二两兩三四五六七八九]+)?/gu;

function integerNumeral(source) {
  const chars = Array.from(source);
  if (chars.every(char => DIGITS.has(char))) return chars.map(char => DIGITS.get(char)).join('');
  // Omitted places are ambiguous: 一百二 can mean 120, not necessarily 102.
  // Keep the original rather than silently accepting a different number.
  if (/[百千万萬亿億][一二两兩三四五六七八九]$/u.test(source)) return null;
  if (BIG_UNITS.has(chars[0])) return null; // e.g. lexical 万一.
  let total = 0;
  let section = 0;
  let digit = null;
  let priorSmall = Infinity;
  let used = false;
  for (let index = 0; index < chars.length; index += 1) {
    const char = chars[index];
    if (DIGITS.has(char)) {
      const value = DIGITS.get(char);
      if (digit !== null && digit !== 0 && value !== 0) return null;
      digit = value;
    } else if (SMALL_UNITS.has(char)) {
      const unit = SMALL_UNITS.get(char);
      if (unit >= priorSmall || (digit === null && index !== 0)) return null;
      section += (digit ?? 1) * unit;
      priorSmall = unit;
      digit = null;
      used = true;
    } else if (BIG_UNITS.has(char)) {
      const unit = BIG_UNITS.get(char);
      section += digit ?? 0;
      if (!section) return null;
      if (unit === 100000000) total = (total + section) * unit;
      else total += section * unit;
      section = 0;
      digit = null;
      priorSmall = Infinity;
      used = true;
    } else return null;
  }
  const result = total + section + (digit ?? 0);
  return used && Number.isSafeInteger(result) ? String(result) : null;
}

function replaceChineseNumeral(source) {
  const negative = /^[负負]/u.test(source);
  const value = negative ? source.slice(1) : source;
  const [integer, decimal] = value.split('点');
  const normalizedInteger = integerNumeral(integer);
  if (normalizedInteger === null) return source;
  const normalizedDecimal = decimal === undefined ? '' : `.${Array.from(decimal).map(char => DIGITS.get(char)).join('')}`;
  return `${negative ? '-' : ''}${normalizedInteger}${normalizedDecimal}`;
}

function speechTokens(value) {
  const normalized = String(value ?? '').normalize('NFKC').toLowerCase()
    .replace(/(?<=\p{L})['’](?=\p{L})/gu, '')
    // Apple ASR formats explicit whole-hour Chinese times as 下午3:00.
    // Only this unambiguous daypart form is numerically equivalent.
    .replace(/(上午|下午|凌晨|早上|晚上|中午)\s*([01]?\d|2[0-3]):00(?!\d)/gu, '$1$2点')
    .replace(NUMERAL_RUN, replaceChineseNumeral);
  // Latin word boundaries remain meaningful: “a part” is not “apart”.
  return normalized.match(/-?\d+(?:\.\d+)?|\p{Script=Han}|[\p{L}\p{M}]+/gu) ?? [];
}

function tokensText(tokens) {
  let text = '';
  for (let i = 0; i < tokens.length; i += 1) {
    const latinBoundary = i > 0 && /^[a-z]/i.test(tokens[i]) && /[a-z]$/i.test(tokens[i - 1]);
    text += `${latinBoundary ? ' ' : ''}${tokens[i]}`;
  }
  return text;
}

/** Ignore punctuation/case/Chinese spacing and normalize unambiguous numerals. */
export function normalizeSpeech(value) { return tokensText(speechTokens(value)); }

/** Use the same sound tolerance for pauses and full-line decisions. */
export function speechPrefix(expected,heard){
  const a=speechTokens(expected),b=speechTokens(heard);
  const matched=comparePronunciation(a,b,{prefix:true});
  return {matches:Boolean(matched),complete:Boolean(matched)&&a.length===b.length};
}

function groupOperations(operations) {
  const differences = [];
  for (const operation of operations) {
    if (operation.type === 'match') continue;
    const prior = differences.at(-1);
    if (prior && prior.type === operation.type && prior._lastStep === operation.step - 1) {
      prior.expectedTokens.push(...operation.expectedTokens);
      prior.heardTokens.push(...operation.heardTokens);
      prior._lastStep = operation.step;
    } else differences.push({...operation, _lastStep: operation.step});
  }
  return differences.map(({type, expectedTokens, heardTokens, expectedIndex, heardIndex}) => ({
    type, expected: tokensText(expectedTokens), heard: tokensText(heardTokens),
    expectedIndex, heardIndex,
  }));
}

/**
 * Compare equal-length spoken sequences with local pronunciation tolerance.
 * No semantic paraphrasing: extra/missing words, numbers and negations matter.
 */
export function compareLine(expected, heard, {candidates=[]}={}) {
  const expectedTokens = speechTokens(expected);
  const heardTokens = speechTokens(heard);
  const pronunciation=comparePronunciation(expectedTokens,heardTokens)
    ||recoverWeakParticle(expectedTokens,heardTokens,(Array.isArray(candidates)?candidates:[]).slice(-16)
      .filter(text=>typeof text==='string'&&text.length<=8000).map(text=>({text,tokens:speechTokens(text)})));
  const equal=Boolean(pronunciation);
  const base = {
    correct: equal, normalizedExpected: tokensText(expectedTokens), normalizedHeard: tokensText(heardTokens),
    expectedTokenCount: expectedTokens.length, heardTokenCount: heardTokens.length,
  };
  if (equal) return {...base, ...pronunciation, differences: []};
  const rows = expectedTokens.length + 1;
  const columns = heardTokens.length + 1;
  // Bound the explanatory
  // alignment's memory footprint without truncating either compared string.
  if (rows * columns > 2_000_000) {
    let prefix = 0;
    while (prefix < expectedTokens.length && prefix < heardTokens.length && expectedTokens[prefix] === heardTokens[prefix]) prefix += 1;
    let suffix = 0;
    while (suffix < expectedTokens.length - prefix && suffix < heardTokens.length - prefix
      && expectedTokens.at(-suffix - 1) === heardTokens.at(-suffix - 1)) suffix += 1;
    return {...base, alignment: 'bounded', differences: [{type: 'replace',
      expected: tokensText(expectedTokens.slice(prefix, expectedTokens.length - suffix)),
      heard: tokensText(heardTokens.slice(prefix, heardTokens.length - suffix)),
      expectedIndex: prefix, heardIndex: prefix}]};
  }
  const distance = new Uint32Array(rows * columns);
  for (let i = 0; i < rows; i += 1) distance[i * columns] = i;
  for (let j = 0; j < columns; j += 1) distance[j] = j;
  for (let i = 1; i < rows; i += 1) {
    for (let j = 1; j < columns; j += 1) {
      distance[i * columns + j] = Math.min(
        distance[(i - 1) * columns + j] + 1,
        distance[i * columns + j - 1] + 1,
        distance[(i - 1) * columns + j - 1] + Number(expectedTokens[i - 1] !== heardTokens[j - 1]),
      );
    }
  }
  const reversed = [];
  let i = expectedTokens.length;
  let j = heardTokens.length;
  while (i || j) {
    const current = distance[i * columns + j];
    if (i && j && expectedTokens[i - 1] === heardTokens[j - 1]) {
      reversed.push({type: 'match', expectedTokens: [expectedTokens[i - 1]], heardTokens: [heardTokens[j - 1]], expectedIndex: i - 1, heardIndex: j - 1});
      i -= 1; j -= 1;
    } else if (i && j && current === distance[(i - 1) * columns + j - 1] + 1) {
      reversed.push({type: 'replace', expectedTokens: [expectedTokens[i - 1]], heardTokens: [heardTokens[j - 1]], expectedIndex: i - 1, heardIndex: j - 1});
      i -= 1; j -= 1;
    } else if (i && current === distance[(i - 1) * columns + j] + 1) {
      reversed.push({type: 'missing', expectedTokens: [expectedTokens[i - 1]], heardTokens: [], expectedIndex: i - 1, heardIndex: j});
      i -= 1;
    } else {
      reversed.push({type: 'extra', expectedTokens: [], heardTokens: [heardTokens[j - 1]], expectedIndex: i, heardIndex: j - 1});
      j -= 1;
    }
  }
  const operations = reversed.reverse().map((operation, step) => ({...operation, step}));
  return {...base, differences: groupOperations(operations)};
}

function copy(value) { return structuredClone(value); }
function joinSegments(parts) {
  return parts.filter(Boolean).reduce((joined, part) => {
    const needsSpace = /[a-z\d]$/i.test(joined) && /^[a-z\d]/i.test(part);
    return `${joined}${needsSpace ? ' ' : ''}${part}`;
  }, '');
}

export class RehearsalSession {
  constructor({turns, myRole, clock = Date.now, minimumConfidence = 0.65, sessionId} = {}) {
    if (!Array.isArray(turns)) throw new TypeError('缺少剧本。');
    this.turns = copy(turns);
    this.myRole = String(myRole ?? '');
    this.dialogue = this.turns.filter(turn => turn.kind === 'dialogue' && String(turn.text).trim());
    if (!this.dialogue.some(turn => turn.role === this.myRole)) throw new Error('请先确认你饰演的角色。');
    if (new Set(this.dialogue.map(turn => turn.id)).size !== this.dialogue.length || this.dialogue.some(turn => !turn.id)) {
      throw new Error('每句台词需要独立的编号。');
    }
    if (typeof clock !== 'function') throw new TypeError('clock 必须是函数。');
    this.clock = clock;
    this.minimumConfidence = minimumConfidence;
    this.sessionId = sessionId ?? `rehearsal-${this.clock()}-${Math.random().toString(36).slice(2, 8)}`;
    this.position = 0;
    this.status = 'idle';
    this.phase = 'idle';
    this.hintLevel = 0;
    this.liveTranscript = '';
    this.attempts = [];
    this.hintEvents = [];
    this.completedTurnIds = [];
    this.startedAt = null;
    this.endedAt = null;
    this.seenUtterances = new Set();
    this._clearBuffer();
  }

  get current() { return this.dialogue[this.position] ? copy(this.dialogue[this.position]) : null; }
  get elapsedMs() {
    return this.startedAt === null ? 0 : Math.max(0, (this.endedAt ?? this.clock()) - this.startedAt);
  }

  snapshot() {
    return copy({sessionId: this.sessionId, status: this.status, phase: this.phase,
      current: this.current, position: this.position, myRole: this.myRole,
      hintLevel: this.hintLevel, hint: this.current?.role === this.myRole ? makeHint(this.current.text, this.hintLevel) : '',
      transcript: this.liveTranscript, elapsedMs: this.elapsedMs,
      progress: {completed: this.completedTurnIds.length, total: this.dialogue.length},
    });
  }

  _event(accepted, kind, extra = {}) { return {accepted, kind, ...extra, snapshot: this.snapshot()}; }
  _clearBuffer() {
    this._segments = [];
    this._hasFinal = false;
    this._hasInterim = false;
    this._bufferStartedMs = null;
    this._bufferUncertain = false;
    this._bufferConfidence = null;
    this.liveTranscript = '';
  }
  _setPhase() { this.phase = this.current?.role === this.myRole ? 'listening' : 'partner'; }
  _advance() {
    this.completedTurnIds.push(this.current.id);
    this.position += 1;
    this.hintLevel = 0;
    this._clearBuffer();
    if (this.position >= this.dialogue.length) {
      this.status = 'complete';
      this.phase = 'complete';
      this.endedAt = this.clock();
    } else this._setPhase();
  }

  start() {
    if (this.status !== 'idle') return this._event(false, 'already_started');
    this.startedAt = this.clock();
    this.status = 'active';
    this._setPhase();
    return this._event(true, 'started');
  }

  partnerFinished(turnId) {
    if (this.status !== 'active' || this.phase !== 'partner' || this.current?.id !== turnId) return this._event(false, 'stale_partner');
    this._advance();
    return this._event(true, 'advanced');
  }

  /** Reset an abandoned ASR hypothesis without recording an actor's mistake. */
  clearAttempt() { this._clearBuffer(); return this.snapshot(); }

  receive({turnId, text = '', isFinal = false, endOfUtterance = true,
    mode = 'snapshot', utteranceId, startMs, endMs, confidence, uncertain = false, candidates=[]} = {}) {
    if (this.status !== 'active' || this.phase !== 'listening') return this._event(false, 'not_listening');
    if (!turnId || this.current?.id !== turnId) return this._event(false, 'stale_turn');
    if (utteranceId && this.seenUtterances.has(`${turnId}:${utteranceId}`)) return this._event(false, 'duplicate');
    if (this._bufferStartedMs === null) this._bufferStartedMs = Number.isFinite(startMs) ? Math.max(0, startMs) : this.elapsedMs;
    if (Number.isFinite(confidence) && confidence >= 0 && confidence <= 1) {
      this._bufferConfidence = this._bufferConfidence === null ? confidence : Math.min(this._bufferConfidence, confidence);
    }
    this._bufferUncertain ||= uncertain;
    const value = String(text);
    if (mode === 'segment') {
      if (isFinal) {
        this._segments.push(value);
        this.liveTranscript = joinSegments(this._segments);
      } else this.liveTranscript = joinSegments([...this._segments, value]);
    } else {
      this.liveTranscript = value;
      if (isFinal) this._segments = [value];
    }
    this._hasInterim = !isFinal;
    this._hasFinal ||= isFinal;
    if (!isFinal) return this._event(true, 'partial');
    if (!endOfUtterance) return this._event(true, 'pending');
    return this.completeUtterance({turnId, utteranceId, endMs, candidates});
  }

  /** Call only after the provider confirms an utterance endpoint. */
  completeUtterance({turnId, utteranceId, startMs, endMs, uncertain = false, confidence, candidates=[]} = {}) {
    if (this.status !== 'active' || this.phase !== 'listening') return this._event(false, 'not_listening');
    if (!turnId || this.current?.id !== turnId) return this._event(false, 'stale_turn');
    const dedupeKey = utteranceId ? `${turnId}:${utteranceId}` : null;
    if (dedupeKey && this.seenUtterances.has(dedupeKey)) return this._event(false, 'duplicate');
    const heard = this.liveTranscript.trim();
    if (!heard || !speechTokens(heard).length) {
      this._clearBuffer();
      return this._event(true, 'silence');
    }
    if (dedupeKey) this.seenUtterances.add(dedupeKey);
    const effectiveConfidence = Number.isFinite(confidence) && confidence >= 0 && confidence <= 1
      ? Math.min(confidence, this._bufferConfidence ?? 1) : this._bufferConfidence;
    const uncertainRecognition = uncertain || this._bufferUncertain || !this._hasFinal || this._hasInterim
      || (effectiveConfidence !== null && effectiveConfidence < this.minimumConfidence);
    const current = this.current;
    const comparison = compareLine(current.text, heard,{candidates});
    const status = uncertainRecognition ? 'uncertain' : comparison.correct ? 'correct' : 'incorrect';
    const start = Number.isFinite(startMs) ? Math.max(0, startMs) : this._bufferStartedMs ?? this.elapsedMs;
    const end = Math.max(start, Number.isFinite(endMs) ? endMs : this.elapsedMs);
    const hintLevelBefore = this.hintLevel;
    if (status === 'incorrect') {
      this.hintLevel = Math.min(2, this.hintLevel + 1);
      this.hintEvents.push({turnId: current.id, level: this.hintLevel, atMs: end, reason: 'recognition_mismatch'});
    }
    const attempt = {
      id: `${this.sessionId}-attempt-${this.attempts.length + 1}`, turnId: current.id,
      role: current.role, scene: current.scene ?? '', sourceLine: current.sourceLine ?? null,
      expected: current.text, heard, status, confidence: effectiveConfidence,
      verdictSource: 'speech-recognition',
      startMs: start, endMs: end, hintLevelBefore, hintLevelAfter: this.hintLevel,
      normalizedExpected: comparison.normalizedExpected, normalizedHeard: comparison.normalizedHeard,
      differences: comparison.differences, matchKind: comparison.matchKind || 'mismatch',
      phoneticMatches: comparison.phoneticMatches || [],
      speechCandidate: comparison.speechCandidate || null,
      recognitionReason: uncertainRecognition ? (!this._hasFinal || this._hasInterim ? 'interim_only' : 'low_reliability') : null,
    };
    this.attempts.push(attempt);
    const hint = makeHint(current.text, this.hintLevel);
    this._clearBuffer();
    if (status === 'correct') this._advance();
    return this._event(true, status, {attempt: copy(attempt), hint, advanced: status === 'correct'});
  }

  revealHint({reason = 'requested', atMs} = {}) {
    if (this.status !== 'active' || this.phase !== 'listening') return this._event(false, 'not_listening');
    this.hintLevel = Math.min(2, this.hintLevel + 1);
    this.hintEvents.push({turnId: this.current.id, level: this.hintLevel,
      atMs: Number.isFinite(atMs) ? Math.max(0, atMs) : this.elapsedMs,
      reason: String(reason).slice(0, 100)});
    return this._event(true, 'hint');
  }

  pause() {
    if (this.status !== 'active') return this._event(false, 'not_active');
    this.status = 'paused';
    this.phase = 'paused';
    this._clearBuffer();
    return this._event(true, 'paused');
  }
  resume() {
    if (this.status !== 'paused') return this._event(false, 'not_paused');
    this.status = 'active';
    this._setPhase();
    return this._event(true, 'resumed');
  }
  stop() {
    if (this.status === 'complete' || this.status === 'stopped') return this._event(false, 'already_ended');
    this.endedAt = this.clock();
    this.status = 'stopped';
    this.phase = 'stopped';
    this._clearBuffer();
    return this._event(true, 'stopped');
  }

  getReport() {
    const ownTurns = this.dialogue.filter(turn => turn.role === this.myRole);
    const lineReports = ownTurns.map(turn => {
      const attempts = this.attempts.filter(attempt => attempt.turnId === turn.id);
      const hints = this.hintEvents.filter(hint => hint.turnId === turn.id);
      const incorrect = attempts.filter(attempt => attempt.status === 'incorrect');
      const uncertain = attempts.filter(attempt => attempt.status === 'uncertain');
      const passed = attempts.some(attempt => attempt.status === 'correct');
      return {turnId: turn.id, role: turn.role, expected: turn.text, scene: turn.scene ?? '', sourceLine: turn.sourceLine ?? null,
        passed, firstTry: passed && !incorrect.length && !hints.length, wrongAttempts: incorrect.length,
        recognitionMismatchAttempts: incorrect.length,
        uncertainAttempts: uncertain.length, hintCount: hints.length, hintLevel: Math.max(0, ...hints.map(hint => hint.level)),
        needsReview: incorrect.length > 0 || hints.length > 0,
        needsChecking: uncertain.length > 0 && !passed,
        startMs: attempts[0]?.startMs ?? null, endMs: attempts.at(-1)?.endMs ?? null,
        attemptIds: attempts.map(attempt => attempt.id)};
    });
    const reviewLines = lineReports.filter(line => line.needsReview || line.needsChecking);
    const reviewIds = new Set();
    const cueGroups = reviewLines.map(line => {
      const index = this.turns.findIndex(turn => turn.id === line.turnId);
      const range = cueRange(this.turns, index);
      const cueTurnIds = this.turns.slice(range.start, range.end + 1)
        .filter(turn => turn.kind === 'dialogue').map(turn => turn.id);
      cueTurnIds.forEach(id => reviewIds.add(id));
      return {turnId: line.turnId, role: line.role, expected: line.expected, cueTurnIds,
        reason: line.needsReview ? 'practice' : 'check_recognition'};
    });
    return copy({schemaVersion: 1, sessionId: this.sessionId, myRole: this.myRole,
      startedAt: this.startedAt === null ? null : new Date(this.startedAt).toISOString(),
      endedAt: this.endedAt === null ? null : new Date(this.endedAt).toISOString(),
      durationMs: this.elapsedMs, status: this.status,
      comparisonLabel: '识别差异',
      note: '差异来自语音识别结果，请结合录音核对；识别可信度不足的片段单列为待确认，不计入识别差异次数。',
      summary: {ownLineCount: ownTurns.length, completedLines: lineReports.filter(line => line.passed).length,
        firstTryLines: lineReports.filter(line => line.firstTry).length,
        unpracticedLines: lineReports.filter(line => !line.attemptIds.length).length,
        recognitionMismatchAttempts: this.attempts.filter(attempt => attempt.status === 'incorrect').length,
        uncertainAttempts: this.attempts.filter(attempt => attempt.status === 'uncertain').length,
        hintedLines: lineReports.filter(line => line.hintCount > 0).length,
        stoppedEarly: this.status === 'stopped' && this.position < this.dialogue.length},
      lines: lineReports, attempts: this.attempts, hints: this.hintEvents,
      review: {turnIds: this.turns.filter(turn => reviewIds.has(turn.id)).map(turn => turn.id), cueGroups},
    });
  }
}

/** Preserve original turn order when constructing the next targeted practice. */
export function buildReviewTurns(turns, report) {
  const ids = new Set(report?.review?.turnIds ?? []);
  return copy(turns.filter(turn => ids.has(turn.id)));
}
