/**
 * Conservative screenplay helpers. No network, DOM, or speech dependencies.
 * Every nonblank source line is retained in a turn's sourceText. Unclassified
 * paragraphs are kept as `unknown` so callers can review, rather than read them.
 */

const DEFAULT_SCENE = '未分场';
const PERSON_LABELS = new Set(['人物', '角色', '人物表', '角色表', '出场人物', '主要人物', '主要角色', '人物介绍', '角色介绍', '人物小传', '演员表', 'cast', 'characters']);
const META_LABELS = new Set([
  ...PERSON_LABELS, '时间', '地点', '日期', '时长', '场景', '场次', '剧名', '片名',
  '标题', '集数', '背景', '背景介绍', '故事背景', '备注', '说明', '注意', '提示',
  '舞台提示', '舞台说明', '动作', '音效', '声音', '音乐', '背景音乐', '灯光',
  '镜头', '画面', '字幕', '道具', '服装', '电话', '联系方式', '拍摄地点', '拍摄时间',
  '姓名', '性别', '年龄', '职业', '人物关系', '角色设定', '角色信息', '角色名',
  '拍摄日期', '日夜', '日/夜', '内外', '内/外', '景别', '镜号', '分镜', '服化道',
  'time', 'location', 'date', 'duration', 'title', 'scene', 'notes', 'note', 'action',
  'sfx', 'music', 'camera', 'subtitle', 'props',
]);
const NON_SPEAKER_WORDS = new Set([
  '清晨', '凌晨', '早晨', '白天', '中午', '午后', '下午', '傍晚', '夜晚', '夜里',
  '深夜', '雨夜', '室内', '室外', '门外', '门口', '楼下', '楼上', '客厅', '卧室',
  '厨房', '街道', '走廊', '医院', '学校', '办公室', '周围', '林间', '张开', '陈旧',
  '终于', '曾经', '明白', '谢谢', '谢了', '别走', '别动', '别怕', '马上', '方才',
  '向前', '向后', '哈哈', '结果', '然后', '现在', '刚才', '后来', '从前', '希望',
  '因为', '所以', '可是', '但是', '不过', '原来', '放心', '当然', '再见', '对不起',
  '没关系', '不用了', '算了', '好了', '好吧', '等一下', '我知道', '是的', '不是',
  '真的', '太好了', '可以', '不能', '能够',
  '继续', '结束', '完', '未完待续', 'CUT TO', 'FADE IN', 'FADE OUT',
]);
const BRACKETS = new Map([['（', '）'], ['(', ')'], ['【', '】'], ['[', ']'], ['{', '}']]);
const CHINESE = /[\p{Script=Han}]/u;
const COMMON_SURNAMES = new Set(Array.from('赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卞齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董梁杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣贲邓郁单杭洪包诸左石崔吉龚程嵇邢滑裴陆荣翁荀羊甄曲封芮羿储靳汲邴糜松井段富巫乌焦巴弓牧隗山谷车侯宓蓬全郗班仰秋仲伊宫宁仇栾暴甘厉戎祖武符刘景詹束龙叶幸司韶黎乔苍双闻莘党翟谭贡劳逄姬申扶堵冉宰郦雍郤璩桑桂濮牛寿通边扈燕冀郏浦尚农温别庄晏柴瞿阎充慕连茹习艾鱼容向古易慎戈廖庾终暨居衡步都耿满弘匡国文寇广禄阙东欧殳沃利蔚越夔隆师巩厍聂晁勾敖融冷訾辛阚那简饶空曾毋沙乜养鞠须丰巢关蒯相查后荆红游竺权逯盖益桓公仉督岳帅缑亢况郈有琴归海晋楚闫法汝鄢涂钦商牟佘佴伯赏墨哈谯笪年爱阳佟言福洛白南北西尉')); 
const ROLE_WORDS = /^(?:我|你|他|她|甲|乙|丙|丁|A|B|C|D|男|女|男孩|女孩|男人|女人|老人|孩子|小孩|父亲|母亲|爸爸|妈妈|哥哥|姐姐|弟弟|妹妹|爷爷|奶奶|叔叔|阿姨|老板|店员|店长|服务员|外卖员|快递员|司机|保安|警察|医生|护士|老师|学生|主持人|旁白|画外音|独白|客人|路人|记者|秘书|助理|男主|女主|男一|女一|男二|女二|角色[\p{L}\p{N}]+|[男女]声|[男女]演员[甲乙丙丁\d]*)$/u;

function labelKey(value) {
  return value.trim().replace(/\s+/g, '').toLowerCase();
}

function stripListPrefix(value) {
  return value.replace(/^\s*(?:[-*•·]\s*|[（(]?\d+[）).、]\s*)/, '').trim();
}

/** Split only at a colon outside a parenthesised action. */
function splitHeader(value) {
  const closing = [];
  for (let i = 0; i < value.length; i += 1) {
    const character = value[i];
    if (BRACKETS.has(character)) closing.push(BRACKETS.get(character));
    else if (closing.length && character === closing.at(-1)) closing.pop();
    else if (!closing.length && (character === ':' || character === '：')) {
      return {head: value.slice(0, i).trim(), body: value.slice(i + 1).trim()};
    }
  }
  return null;
}

/** Parenthesised stage instructions stay available next to the spoken text. */
function extractDirections(value) {
  let text = '';
  const directions = [];
  let unclosed = false;
  for (let i = 0; i < value.length; i += 1) {
    const character = value[i];
    if (!BRACKETS.has(character)) {
      text += character;
      continue;
    }
    const closing = [BRACKETS.get(character)];
    let j = i + 1;
    for (; j < value.length && closing.length; j += 1) {
      if (BRACKETS.has(value[j])) closing.push(BRACKETS.get(value[j]));
      else if (value[j] === closing.at(-1)) closing.pop();
    }
    if (closing.length) {
      // An unfinished bracket is not silently removed.
      text += value.slice(i);
      unclosed = true;
      break;
    }
    directions.push(value.slice(i, j));
    i = j - 1;
  }
  return {text: text.replace(/[ \t]{2,}/g, ' ').trim(), directions, unclosed};
}

function cleanRole(value) {
  return extractDirections(stripListPrefix(value)).text.replace(/[ \t]+/g, ' ').trim();
}

function isRoleName(value) {
  const name = cleanRole(value);
  if (!name || META_LABELS.has(labelKey(name)) || NON_SPEAKER_WORDS.has(name)) return false;
  if (!/[\p{L}]/u.test(name) || !/^[\p{L}\p{N}·・.'’\- ]+$/u.test(name)) return false;
  if (name.length > (CHINESE.test(name) ? 12 : 40) || name.split(/\s+/).length > 4) return false;
  if (/^(?:第[\d零〇一二三四五六七八九十百两]+[场幕集]|\d)/u.test(name)) return false;
  if (/(?:说道|问道|喊道|叫道|回答|表示|提醒|认为|如下|包括|补充|解释|说明|想法|是|说|问)$/u.test(name)) return false;
  return true;
}

function looksLikeStandaloneRole(value, knownRoles) {
  const name = cleanRole(value);
  if (!isRoleName(value)) return false;
  if (knownRoles.has(name) || ROLE_WORDS.test(name)) return true;
  if (/^[\p{Script=Han}]{2,4}$/u.test(name)) {
    return COMMON_SURNAMES.has(name[0]) || /^[小老阿]/u.test(name);
  }
  if (/^[A-Z][A-Z\d .'-]{0,29}$/.test(name)) return true;
  return /^[A-Z][a-z]+(?: [A-Z][a-z]+){0,2}$/.test(name);
}

function sceneTitle(value) {
  const trimmed = value.trim().replace(/^#{1,6}\s*/, '');
  const unnumbered = trimmed.replace(/^\d+[、.]\s*/, '');
  if (/^(?:场景|场次)\s*[:：]\s*\S/u.test(trimmed)) return trimmed;
  if (/^第[\d零〇一二三四五六七八九十百千万两]+[场幕集](?:\s|[:：、.\-—|｜]|$)/u.test(trimmed)) return trimmed;
  if (/^(?:场|场次|场景)\s*[\d零〇一二三四五六七八九十百两]+(?:\s|[:：、.\-—|｜]|$)/u.test(trimmed)) return trimmed;
  if (/^\d{1,3}[-－—.]\d{1,3}(?:\s|[:：、]|$)/u.test(trimmed)) return trimmed;
  if (/^(?:内景|外景|内外景|内\/外景)(?:\s|[.：:、\-—]|$)/u.test(unnumbered)) return trimmed;
  if (/^(?:INT\.?|EXT\.?|INT\.?\/EXT\.?|I\/E\.?)\s+/i.test(unnumbered)) return trimmed;
  if (/^SCENE\s+[\w一二三四五六七八九十]+(?:\s|[:：.\-—]|$)/i.test(trimmed)) return trimmed;
  if (/^[内外]\s+.+\s+[日夜晨昏]$/u.test(unnumbered)) return trimmed;
  return null;
}

function metadata(value) {
  const header = splitHeader(value);
  if (header && META_LABELS.has(labelKey(header.head))) {
    return {...header, personnel: PERSON_LABELS.has(labelKey(header.head))};
  }
  const bare = value.replace(/[:：]\s*$/, '').trim();
  if (PERSON_LABELS.has(labelKey(bare))) return {head: bare, body: '', personnel: true};
  return null;
}

function explicitDirection(value) {
  const {text, directions} = extractDirections(value);
  if (!text && directions.length) return true;
  return /^(?:[△▲※]|(?:舞台提示|舞台说明|动作|镜头|画面|音效|字幕|灯光)\s*[:：])/u.test(value)
    || /^(?:CUT TO:|FADE IN:|FADE OUT\.?|END OF SCENE\.?)/i.test(value);
}

function rosterNames(value) {
  const segments = [];
  const closing = [];
  let start = 0;
  for (let i = 0; i <= value.length; i += 1) {
    const character = value[i];
    if (BRACKETS.has(character)) closing.push(BRACKETS.get(character));
    else if (closing.length && character === closing.at(-1)) closing.pop();
    if (i === value.length || (!closing.length && /[、,，;；|｜/]/u.test(character))) {
      const name = cleanRole(value.slice(start, i));
      if (isRoleName(name)) segments.push(name);
      start = i + 1;
    }
  }
  return segments;
}

function isBiography(body) {
  return /^(?:[男女](?:性|演员)?(?:[\s，,、；;。:]|\d|$)|\d{1,2}\s*岁|年龄|性别|职业|饰演|扮演|[（(][男女])/u.test(body);
}

/**
 * Parse one or more scenes. sourceLine is 1-based, IDs follow source order.
 * `sourceText` preserves original text; `direction` is never spoken dialogue.
 */
export function parseScript(raw) {
  const normalized = String(raw ?? '').replace(/^\uFEFF/u, '').replace(/\r\n?/g, '\n');
  const lines = normalized.split('\n');
  const knownRoles = new Set();
  const rosterLines = new Set();
  let inRoster = false;

  // First establish explicit names and identify cast biographies. This prevents
  // a cast entry such as “林夏：女，25岁” from becoming a spoken turn.
  lines.forEach((line, index) => {
    const value = line.trim();
    if (!value) return;
    if (sceneTitle(value)) { inRoster = false; return; }
    const meta = metadata(value);
    if (meta) {
      inRoster = meta.personnel && !meta.body;
      if (meta.personnel) rosterNames(meta.body).forEach(name => knownRoles.add(name));
      return;
    }
    const header = splitHeader(value);
    if (inRoster) {
      if (header && isRoleName(header.head) && isBiography(header.body)) {
        knownRoles.add(cleanRole(header.head));
        rosterLines.add(index);
        return;
      }
      if (header && isRoleName(header.head)) {
        inRoster = false;
      } else {
        rosterNames(value).forEach(name => knownRoles.add(name));
        rosterLines.add(index);
        return;
      }
    }
    if (header && isRoleName(header.head)) knownRoles.add(cleanRole(header.head));
  });

  const turns = [];
  const warnings = [];
  const warned = new Set();
  let scene = DEFAULT_SCENE;
  let current = null;
  let blankSinceText = false;

  function warn(key, message) {
    if (!warned.has(key)) { warned.add(key); warnings.push(message); }
  }
  function pushTurn(turn) {
    turns.push({...turn, id: `turn-${turns.length + 1}`});
  }
  function flush() {
    if (!current) return;
    if (current.text.trim()) {
      current.text = current.text.trim();
      pushTurn(current);
    } else if (current.direction) {
      pushTurn({...current, kind: 'direction', text: current.sourceText.trim()});
    } else {
      pushTurn({...current, kind: 'unknown', role: '', text: current.sourceText.trim()});
      warn(`empty-${current.sourceLine}`, `第 ${current.sourceLine} 行只有角色名，未找到后续台词，已保留待确认。`);
    }
    current = null;
    blankSinceText = false;
  }
  function appendSource(turn, line) {
    turn.sourceText += `\n${line}`;
  }
  function appendDirections(turn, items) {
    if (items.length) turn.direction = [turn.direction, ...items].filter(Boolean).join(' ');
  }
  function addUnknown(line, index) {
    const previous = turns.at(-1);
    if (previous?.kind === 'unknown' && previous.scene === scene && previous._lastLine === index) {
      previous.text += `\n${line.trim()}`;
      appendSource(previous, line);
      previous._lastLine = index + 1;
      return;
    }
    pushTurn({kind: 'unknown', role: '', text: line.trim(), scene, sourceLine: index + 1, sourceText: line, _lastLine: index + 1});
    warn(`unknown-${index}`, `第 ${index + 1} 行有未识别段落，已保留待确认，不会自动朗读。`);
  }
  function canStartStandalone(index) {
    // Blank lines and an explicit action can occur between a character name
    // and their speech. Stop at a different header, scene, or metadata block.
    for (let cursor = index + 1; cursor < lines.length; cursor += 1) {
      const value = lines[cursor].trim();
      if (!value) continue;
      if (sceneTitle(value) || metadata(value) || rosterLines.has(cursor)) return false;
      if (explicitDirection(value)) continue;
      const header = splitHeader(value);
      if (header && isRoleName(header.head)) return false;
      if (looksLikeStandaloneRole(value, knownRoles)) return false;
      return true;
    }
    return false;
  }
  function beginDialogue(role, body, line, index, headDirections = []) {
    flush();
    const cleaned = extractDirections(body);
    current = {kind: 'dialogue', role, text: cleaned.text, scene, sourceLine: index + 1, sourceText: line};
    appendDirections(current, [...headDirections, ...cleaned.directions]);
    if (cleaned.unclosed) {
      current.kind = 'unknown';
      warn(`bracket-${index}`, `第 ${index + 1} 行的括号未闭合，已保留待确认，不会自动朗读。`);
    }
    knownRoles.add(role);
  }

  lines.forEach((line, index) => {
    const value = line.trim();
    if (!value) {
      if (current) appendSource(current, line);
      blankSinceText = Boolean(current?.text);
      return;
    }
    const heading = sceneTitle(value);
    if (heading) {
      flush();
      scene = heading;
      pushTurn({kind: 'direction', role: '', text: value, scene, sourceLine: index + 1, sourceText: line, isSceneHeading: true});
      return;
    }
    if (metadata(value) || rosterLines.has(index)) {
      flush();
      pushTurn({kind: 'direction', role: '', text: value, scene, sourceLine: index + 1, sourceText: line});
      return;
    }
    if (explicitDirection(value)) {
      if (current) {
        appendSource(current, line);
        appendDirections(current, [value]);
        blankSinceText = false;
      } else {
        pushTurn({kind: 'direction', role: '', text: value, scene, sourceLine: index + 1, sourceText: line});
      }
      return;
    }
    const header = splitHeader(value);
    if (header && isRoleName(header.head)) {
      const cleanedHead = extractDirections(stripListPrefix(header.head));
      beginDialogue(cleanRole(header.head), header.body, line, index, cleanedHead.directions);
      return;
    }
    if (looksLikeStandaloneRole(value, knownRoles) && canStartStandalone(index)) {
      const cleanedHead = extractDirections(stripListPrefix(value));
      beginDialogue(cleanRole(value), '', line, index, cleanedHead.directions);
      warn('standalone-roles', '已按独立成行的角色名分配部分台词，请在开始前核对角色和分行。');
      return;
    }
    if (current && !blankSinceText) {
      const cleaned = extractDirections(value);
      current.text = [current.text, cleaned.text].filter(Boolean).join('\n');
      appendSource(current, line);
      appendDirections(current, cleaned.directions);
      if (cleaned.unclosed) {
        current.kind = 'unknown';
        warn(`bracket-${index}`, `第 ${index + 1} 行的括号未闭合，已保留待确认，不会自动朗读。`);
      }
      return;
    }
    // A new unlabelled paragraph after a blank line is ambiguous. Keep it
    // visible for review rather than accidentally reading prose as dialogue.
    flush();
    addUnknown(line, index);
  });
  flush();

  for (const turn of turns) delete turn._lastLine;
  const characters = [...new Set(turns.filter(turn => turn.kind === 'dialogue').map(turn => turn.role))];
  if (!characters.length && normalized.trim()) {
    warn('no-dialogue', '暂未找到可练习的角色台词。可使用“角色名：台词”，或核对保留的待确认段落。');
  }
  return {turns, characters, warnings};
}

/** 0 = concealed, 1 = a short opening cue, 2 = the complete original text. */
export function makeHint(text, level = 0) {
  const original = String(text ?? '');
  if (Number(level) >= 2) return original;
  if (Number(level) < 1 || !Number.isFinite(Number(level))) return '';
  const trimmed = original.trim();
  if (!trimmed) return '';
  if (CHINESE.test(trimmed)) {
    const characters = typeof Intl?.Segmenter === 'function'
      ? [...new Intl.Segmenter('zh', {granularity: 'grapheme'}).segment(trimmed)].map(part => part.segment)
      : Array.from(trimmed);
    return characters.length > 3 ? `${characters.slice(0, 3).join('')}…` : trimmed;
  }
  const matches = [...trimmed.matchAll(/\S+/gu)];
  if (matches.length <= 2) return trimmed;
  const end = matches[1].index + matches[1][0].length;
  return `${trimmed.slice(0, end)}…`;
}

/** Inclusive original-turn indexes; never crosses a scene boundary. */
export function cueRange(turns, index) {
  if (!Array.isArray(turns) || !Number.isInteger(index) || index < 0 || index >= turns.length) {
    return {start: -1, end: -1};
  }
  const current = turns[index];
  if (current.kind !== 'dialogue') return {start: index, end: index};
  for (let cursor = index - 1; cursor >= 0; cursor -= 1) {
    const candidate = turns[cursor];
    if (candidate.scene !== current.scene || candidate.isSceneHeading) break;
    if (candidate.kind === 'dialogue' && candidate.role !== current.role) {
      return {start: cursor, end: index};
    }
  }
  return {start: index, end: index};
}

function markChecker(marks) {
  if (marks instanceof Set) return (id, index) => marks.has(id) || marks.has(index);
  if (Array.isArray(marks)) {
    const set = new Set(marks);
    return (id, index) => set.has(id) || set.has(index);
  }
  return (id, index) => Boolean(marks && (marks[id] || marks[index]));
}

/**
 * Returns original-turn indexes, including cue lines in marked-only practice.
 * `scene` omitted/null/empty/'all'/'__all__' means all scenes. `marks` accepts
 * turn-ID Sets, Arrays, or truthy object maps; myRole filters marked anchors only.
 */
export function getPracticeIndices(turns, {scene, markedOnly = false, marks, myRole} = {}) {
  if (!Array.isArray(turns)) return [];
  const allScenes = scene == null || scene === '' || scene === 'all' || scene === '__all__';
  const matchesScene = turn => allScenes || turn.scene === scene;
  if (!markedOnly) {
    return turns.flatMap((turn, index) => turn.kind === 'dialogue' && matchesScene(turn) ? [index] : []);
  }
  const marked = markChecker(marks);
  const indices = new Set();
  turns.forEach((turn, index) => {
    if (turn.kind !== 'dialogue' || !matchesScene(turn) || (myRole && turn.role !== myRole) || !marked(turn.id, index)) return;
    const range = cueRange(turns, index);
    for (let cursor = range.start; cursor <= range.end; cursor += 1) {
      if (turns[cursor].kind === 'dialogue' && matchesScene(turns[cursor])) indices.add(cursor);
    }
  });
  return [...indices].sort((a, b) => a - b);
}

/** A role cannot be inferred from an actor's gender or from the screenplay. */
export function prepareScript(raw) {
  const parsed = parseScript(raw);
  const unknownTurns = parsed.turns.filter(turn => turn.kind === 'unknown');
  return {...parsed, unknownTurns, needsRoleConfirmation: true,
    canChooseRole: parsed.characters.length > 0};
}

/**
 * Unknown paragraphs are retained and require explicit review before starting.
 * Set acknowledgeUnknown only after showing those paragraphs to the user.
 */
export function confirmRole(parsed, myRole, {acknowledgeUnknown = false} = {}) {
  if (!parsed || !Array.isArray(parsed.turns)) throw new TypeError('请先导入并解析剧本。');
  const characters = [...new Set(parsed.turns.filter(turn => turn.kind === 'dialogue').map(turn => turn.role))];
  if (!characters.includes(myRole)) throw new Error('请确认你要饰演的角色。');
  const unknownTurns = parsed.turns.filter(turn => turn.kind === 'unknown');
  if (unknownTurns.length && !acknowledgeUnknown) {
    return {ready: false, reason: 'unreviewed_paragraphs', myRole, unknownTurns};
  }
  return {ready: true, myRole, turns: parsed.turns.map(turn => ({...turn})),
    myLines: parsed.turns.filter(turn => turn.kind === 'dialogue' && turn.role === myRole),
    partnerLines: parsed.turns.filter(turn => turn.kind === 'dialogue' && turn.role !== myRole),
    unknownTurns};
}
