/** Keep the imported script and every review copy in separate persistence slots. */
const copy=value=>structuredClone(value);
const baseName=name=>String(name || '新剧本').replace(/(?: · 错句重练)+$/u,'');

export class ScriptWorkspace {
  constructor(draft={}) {
    this.main={script:copy(draft?.script ?? null),myRole:draft?.myRole || ''};
    this.review=draft?.reviewDraft?.script ? copy(draft.reviewDraft) : null;
    this.isReview=false; // Relaunch always makes the complete original easy to find.
  }
  get current(){return this.isReview?this.review:this.main;}
  updateCurrent(patch){Object.assign(this.current,copy(patch));}
  replaceMain(patch){this.main=copy(patch);this.review=null;this.isReview=false;}
  showMain(){this.isReview=false;}
  showReview(){if(this.review)this.isReview=true;}
  fromRecord(record,turns=null){
    const script=copy(record.script);
    if(turns){script.turns=copy(turns);script.name=`${baseName(record.title)} · 错句重练`;script.characters=[...new Set(turns.filter(t=>t.kind==='dialogue').map(t=>t.role))];script.warnings=[];}
    this.review={script,myRole:record.myRole,sourceScript:copy(record.practice?.sourceScript || record.script),sourceMyRole:record.practice?.sourceMyRole || record.myRole,parentSessionId:record.id};
    this.isReview=true;
  }
  recordingContext(){return this.isReview?{kind:'review',sourceScript:copy(this.review.sourceScript),sourceMyRole:this.review.sourceMyRole,parentSessionId:this.review.parentSessionId}:{kind:'main'};}
  serialize(){return copy({schemaVersion:2,...this.main,reviewDraft:this.review});}
}

/** Recover the legacy overwrite only from a matching, complete recorded script.
 * Names, roles, original IDs, exact text and order must all agree. Never guess
 * from a merely similar title, and never rewrite any historical recording.
 */
export function recoverLegacyReviewDraft(draft,records){
  if(!draft?.script || draft.schemaVersion===2 || !/ · 错句重练$/u.test(draft.script.name || ''))return null;
  const title=baseName(draft.script.name),subset=draft.script.turns;
  if(!subset?.length)return null;
  const candidates=records.filter(record=>{
    if(!record.script?.turns?.length || record.myRole!==draft.myRole || record.script.name!==title || / · 错句重练$/u.test(record.title || ''))return false;
    let cursor=-1;
    return subset.every(turn=>{
      const index=record.script.turns.findIndex((original,i)=>i>cursor && original.id===turn.id && original.kind===turn.kind && original.role===turn.role && original.text===turn.text);
      if(index<0)return false;cursor=index;return true;
    });
  }).sort((a,b)=>String(b.startedAt).localeCompare(String(a.startedAt)));
  const original=candidates[0];if(!original)return null;
  const workspace=new ScriptWorkspace({script:original.script,myRole:original.myRole});
  workspace.fromRecord({...original,script:draft.script});
  workspace.review.sourceScript=copy(original.script);
  return workspace.serialize();
}
