import { normalizeSpeech, speechPrefix, compareLine } from './rehearsal.mjs';
const join = (a,b) => a && b ? `${a}${/[a-z\d]$/i.test(a) && /^[a-z\d]/i.test(b) ? ' ' : ''}${b}` : a || b;

/** A VAD commit is a speech fragment; a correct prefix waits without scoring. */
export class TurnSegments {
  constructor(expected,{deferIncomplete=false}={}) { this.expected=expected; this.target=normalizeSpeech(expected);this.text='';this.candidates=[];this.seen=new Set();this.deferIncomplete=deferIncomplete; }
  partial(text) { return join(this.text,text); }
  committed({text,segment,candidates=[]}) {
    const id=String(segment);
    if(this.seen.has(id))return {kind:'duplicate',text:this.text};
    this.seen.add(id);
    const part=String(text || '').trim();
    if(!normalizeSpeech(part))return {kind:'empty',text:this.text};
    const combined=join(this.text,part);
    const options=[...this.candidates.map(c=>join(c,part)),...candidates.map(c=>join(this.text,c))].slice(-16);
    if(!compareLine(this.expected,combined,{candidates:options}).correct&&!speechPrefix(this.expected,combined).matches&&this.text&&
      (speechPrefix(this.expected,part).matches||compareLine(this.expected,part,{candidates}).correct)){
      this.text=part;this.candidates=candidates; // actor restarts from the beginning
    }else{this.text=combined;this.candidates=options;}
    const match=compareLine(this.expected,this.text,{candidates:this.candidates});
    if(match.correct)return this.flush();
    const prefix=speechPrefix(this.expected,this.text);
    if(prefix.matches&&!prefix.complete)return {kind:'prefix',text:this.text};
    // Faster endpoints may split a sentence just after a misrecognized syllable.
    // Give a short fragment a continuation window instead of counting a mistake.
    if(this.deferIncomplete&&match.heardTokenCount<match.expectedTokenCount)return {kind:'pending',text:this.text};
    return this.flush();
  }
  flush(){const result={kind:'utterance',text:this.text,...(this.candidates.length?{candidates:this.candidates}:{})};this.clear();return result;}
  clear() { this.text='';this.candidates=[]; }
}
