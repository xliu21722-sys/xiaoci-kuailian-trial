// Vendored by npm into the installed app, loaded as a local ESM file in Electron.
// No HTTP request, model download, API key, telemetry or cloud correction.
import {pinyin} from '../../node_modules/pinyin-pro/dist/index.mjs';
const HAN=/^\p{Script=Han}$/u;
const NEGATIONS=new Set(Array.from('不没沒无無未非否别別勿莫甭'));
const OPPOSITES=['买卖','買賣','有无','有無','是非','生死','输赢','輸贏','上下','前后','前後','左右','进退','進退','增减','增減','早晚','开关','開關','真假','冷热','冷熱','多少','高低','内外','內外','来去','來去','借还','借還'];
const particles=new Set(['吗','嗎','么','麼','嘛']);
// A particle is different from the lexical 么 in 什么/怎么/那么. Only a
// small, anchored weak syllable may be polished; never a missing content word.
export function weakParticleAt(tokens,index){
  const c=tokens[index];
  return particles.has(c)&&!('么麼'.includes(c)&&/[什怎这這那多恁]/u.test(tokens[index-1] || ''));
}
function weakSound(expected,heard,index){
  return expected.length>=6&&index>=2&&weakParticleAt(expected,index)
    &&new Set(['吗','嗎','嘛','么','麼','吧','呗','唄','某']).has(heard[index]);
}

function readings(tokens){
  const result=tokens.map(()=>null);
  for(let i=0;i<tokens.length;){
    if(!HAN.test(tokens[i])){i++;continue;}
    let end=i+1;while(end<tokens.length&&HAN.test(tokens[end]))end++;
    // Read phrases together so 银行/重庆 use their contextual pronunciations.
    const values=pinyin(tokens.slice(i,end).join(''),{toneType:'none',type:'array'});
    if(values.length===end-i)for(let j=i;j<end;j++)if(/^[a-zü]+$/u.test(values[j-i]))result[j]=values[j-i];
    i=end;
  }
  return result;
}
function nearSound(a,b){
  const x=a.match(/^(zh|ch|sh|[bpmfdtnlgkhjqxrzcsyw]?)(.*)$/u);
  const y=b.match(/^(zh|ch|sh|[bpmfdtnlgkhjqxrzcsyw]?)(.*)$/u);
  if(!x||!y)return false;
  const pair=(u,v,pairs)=>pairs.some(([a,b])=>(u===a&&v===b)||(u===b&&v===a));
  // Allow one familiar accent difference, never arbitrary edit-distance similarity.
  return x[2]===y[2]&&pair(x[1],y[1],[['zh','z'],['ch','c'],['sh','s'],['n','l']])
    || x[1]===y[1]&&pair(x[2],y[2],[['en','eng'],['in','ing']]);
}

export function comparePronunciation(expected,heard,{prefix=false}={}){
  if(!heard.length || heard.length>expected.length || (!prefix&&expected.length!==heard.length))return null;
  const changes=[];
  for(let i=0;i<heard.length;i++)if(expected[i]!==heard[i])changes.push(i);
  if(!changes.length)return {matchKind:'exact',phoneticMatches:[]};
  // Numbers, Latin words, negation changes and explicit antonyms cannot be rescued.
  if(changes.some(i=>!HAN.test(expected[i])||!HAN.test(heard[i])||NEGATIONS.has(expected[i])||NEGATIONS.has(heard[i])||OPPOSITES.some(pair=>pair.includes(expected[i])&&pair.includes(heard[i]))))return null;
  const a=readings(expected),b=readings(heard),matches=[];
  let near=0,weak=0;
  for(const index of changes){
    let kind;
    if(a[index]&&a[index]===b[index])kind='homophone';
    else if(weakParticleAt(expected,index)&&weakParticleAt(heard,index))kind='particle';
    else if(weakSound(expected,heard,index)){kind='weak-particle';weak++;}
    // Lightly articulated 的+particle may be recognized as 那么. Require a
    // matching word on each side and a long context, not a general 的/那 alias.
    else if(expected[index]==='的'&&heard[index]==='那'&&weakSound(expected,heard,index+1)
      &&index>=2&&index+2<heard.length&&expected[index-1]===heard[index-1]&&expected[index+2]===heard[index+2]){kind='weak-link';weak++;}
    else if(expected.length>=3&&a[index]&&b[index]&&nearSound(a[index],b[index])){kind='near-sound';near++;}
    else return null;
    matches.push({index,expected:expected[index],heard:heard[index],kind});
  }
  // Near sounds need surrounding context; matching every word by vague similarity
  // would hide a different sentence. Same-pinyin substitutions do not use this cap.
  if(near>Math.max(1,Math.floor(heard.length/8))||weak>2)return null;
  return {matchKind:weak?'speech-polish':near?'near-sound':'homophone',phoneticMatches:matches};
}

// Rescue a swallowed particle only when the recognizer itself produced it for
// THIS audio. All surrounding words must agree with the final transcript. We
// never fill in the script, rescue a negation/number, or use a different turn.
export function recoverWeakParticle(expected,heard,candidates){
  if(expected.length<6||heard.length!==expected.length-1)return null;
  for(const candidate of candidates){
    if(candidate.tokens.length>expected.length)continue;
    for(let i=2;i<expected.length;i++){
      if(!weakParticleAt(expected,i)||candidate.tokens.length<=i)continue;
      if(!candidate.tokens.filter((_,j)=>j!==i).every((t,j)=>t===heard[j]))continue;
      // A provisional prefix may contain the syllable before the recognizer
      // removes it. Use only that observed syllable, plus the FINAL surrounding
      // words, not an expected-script token or a guessed remainder.
      const supported=[...heard];supported.splice(i,0,candidate.tokens[i]);
      const match=comparePronunciation(expected,supported);
      if(match)return {...match,matchKind:'speech-candidate',speechCandidate:candidate.text,
        phoneticMatches:[...match.phoneticMatches,{index:i,expected:expected[i],heard:'',kind:'candidate-particle'}]};
    }
  }
  return null;
}
