"""Sign only a locally built Duici bundle, inside out. Never changes Gatekeeper.

This produces ad-hoc signatures for this Mac, NOT Developer ID or notarization.
Libraries get no app capabilities; only executable app bundles get JIT/audio.
"""
from pathlib import Path
import argparse
import json
import plistlib
import subprocess
import sys
import tempfile

MAGIC = {b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf',
         b'\xfe\xed\xfa\xce', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
         b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'}


def run(*args):
    subprocess.run(args, check=True)


def sign(app):
    if sys.platform != 'darwin':
        raise SystemExit('本机试用签名只能在 macOS 上执行。')
    app = Path(app).absolute()
    if app.is_symlink() or not app.is_dir() or app.suffix != '.app':
        raise SystemExit('请指定一个独立的本机试用 .app 副本。')
    info = plistlib.loads((app / 'Contents/Info.plist').read_bytes())
    if info.get('CFBundleIdentifier') != 'local.duici.rehearsal':
        raise SystemExit('应用标识不符，未签名。')
    if not info.get('NSMicrophoneUsageDescription'):
        raise SystemExit('缺少麦克风用途说明，未签名。')
    # Refuse external symlinks. Electron's standard versioned framework links stay inside.
    for path in app.rglob('*'):
        if path.is_symlink() and not path.resolve().is_relative_to(app.resolve()):
            raise SystemExit(f'组件软链接指向应用之外：{path.relative_to(app)}')
    bundles = [app] + [p for p in app.rglob('*')
                       if not p.is_symlink() and p.is_dir() and p.suffix in {'.app', '.framework'}]
    sealed_executables = set()
    for bundle in bundles:
        plist = (bundle / 'Contents/Info.plist' if bundle.suffix == '.app'
                 else bundle / 'Resources/Info.plist')
        value = plistlib.loads(plist.read_bytes())
        exe = (bundle / 'Contents/MacOS' / value['CFBundleExecutable']
               if bundle.suffix == '.app' else bundle / value['CFBundleExecutable'])
        sealed_executables.add(exe.resolve())
    loose = []
    for path in app.rglob('*'):
        if path.is_file() and not path.is_symlink():
            with path.open('rb') as source:
                is_macho = source.read(4) in MAGIC
            if is_macho and path.resolve() not in sealed_executables:
                loose.append(path)
    jobs = sorted(bundles + loose, key=lambda p: len(p.parts), reverse=True)
    report = []
    with tempfile.TemporaryDirectory(prefix='duici-local-sign-') as temporary:
        jit = Path(temporary) / 'jit.plist'
        microphone = Path(temporary) / 'microphone.plist'
        jit.write_bytes(plistlib.dumps({'com.apple.security.cs.allow-jit': True}))
        microphone.write_bytes(plistlib.dumps({'com.apple.security.cs.allow-jit': True,
                                              'com.apple.security.device.audio-input': True}))
        for target in jobs:
            command = ['/usr/bin/codesign', '--force', '--sign', '-', '--timestamp=none']
            rights = 'none'
            if target.suffix == '.app':
                # Generic utility helper hosts audio capture; GPU/Renderer/Plugin do not need mic rights.
                # Packager may assign the same bundle ID to every helper.
                # Only its unsuffixed utility helper captures audio.
                generic_helper = app / 'Contents/Frameworks' / (info['CFBundleExecutable'] + ' Helper.app')
                mic = target == app or target == generic_helper
                command += ['--entitlements', str(microphone if mic else jit)]
                rights = 'jit+microphone' if mic else 'jit'
            command.append(str(target))
            run(*command)
            report.append({'path': str(target.relative_to(app)), 'entitlements': rights})
    run('/usr/bin/codesign', '--verify', '--deep', '--strict', '--verbose=2', str(app))
    print(json.dumps({'bundle': str(app), 'signature': 'local-ad-hoc',
                      'notarized': False, 'signedInsideOut': report}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('app')
    sign(parser.parse_args().app)
