// Explicit public PREVIEW builds; this does not weaken the notarized release gate.
import {packager} from '@electron/packager';
import {readFile,mkdir,writeFile,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
const root=fileURLToPath(new URL('..',import.meta.url)),pkg=JSON.parse(await readFile(join(root,'package.json')));
const [platform,arch]=process.argv.slice(2);
if(!['darwin','win32'].includes(platform)||!['arm64','x64'].includes(arch))throw Error('Usage: node scripts/package-trial.mjs darwin|win32 arm64|x64');
await readFile(join(root,'portable-dist/index.html'));
const checksums=JSON.parse(await readFile(join(root,'node_modules/electron/checksums.json')));
const result=await packager({dir:root,name:pkg.productName,executableName:pkg.productName,appBundleId:'local.duici.rehearsal',appVersion:pkg.version,
  platform,arch,electronVersion:pkg.devDependencies.electron,download:{checksums},
  out:join(root,'build-trial'),overwrite:true,asar:{unpack:'**/native/local-{voice,asr}'},prune:true,
  icon:platform==='darwin'?join(root,'assets/app.icns'):join(root,'assets/app.ico'),
  ignore:[/^\/(?:assets|build|build-local|build-trial|release|release-trial|tests|docs|scripts|speech-assets|evidence|\.git|\.public-trial|\.preview|\.impeccable)(?:\/|$)/,/verification\.(?:js|html)$/],
  extendInfo:{CFBundleDisplayName:pkg.productName,LSMinimumSystemVersion:'13.0',NSMicrophoneUsageDescription:'在本机识别台词并录下对词，用于回听。不会上传麦克风音频。',NSHumanReadableCopyright:'小词快练 · 跨平台试用，未公证'},
  usageDescription:{Microphone:'在本机识别台词并保存对词录音。'},
  win32metadata:{CompanyName:'小词快练',FileDescription:'小词快练桌面对词工具',ProductName:pkg.productName}
});
const directory=result[0];
if(platform==='darwin'){
  if(process.platform!=='darwin')throw Error('Mac 试用包必须在 Mac 严格签名验证。');
  const sign=spawnSync('/usr/bin/python3',[join(root,'scripts/sign-local-mac.py'),join(directory,pkg.productName+'.app')],{stdio:'inherit'});
  if(sign.status!==0)throw Error('试用签名验证未通过。');
}
const guide=`<!doctype html><meta charset="utf-8"><title>小词快练 · 开始使用</title><style>body{max-width:740px;margin:40px auto;padding:24px;font:17px/1.8 system-ui;color:#292c27}a{color:#31674f}</style><h1>小词快练 ${pkg.version} 试用版</h1><p>不想安装？<a href="https://xliu21722-sys.github.io/xiaoci-kuailian-trial/">直接打开浏览器版</a>，使用最新版 Chrome 或 Edge，允许麦克风即可。</p><h2>安装</h2><p>${platform==='darwin'?'需要 macOS 13 或更新系统。把“小词快练.app”拖到“应用程序”。当前为本地签名试用包，未完成 Apple 公证；如果系统拦截，先确认下载来自本项目，再在“系统设置 → 隐私与安全性”中查看对应应用的“仍要打开”提示。如没有该选项，请使用浏览器版；不要关闭 Gatekeeper。':'需要 Windows 10/11。请先解压整个 ZIP，再双击“小词快练.exe”，保留同目录的其他文件。本试用包未购买代码签名证书，系统可能提示未知发行者；若电脑策略禁止运行，请使用浏览器版。'}</p><h2>练一遍</h2><ol><li>内置四句练习，选择苏晴；也可以导入自己的剧本。</li><li>离线声音和中文核对不需要密钥。点“开始对词”，允许麦克风。</li><li>轮到你时直接说台词。结束后在“录音”中回听，也可单独回练。</li></ol><p>Fish 声音与克隆使用你自己的账户。免费模型不可用时停止，不自动改为收费模型。模型和软件不包含开发者的密钥、剧本或录音。</p><p>以上仅为节奏参考，最终表演以导演现场要求为准。</p><p><a href="https://xliu21722-sys.github.io/xiaoci-kuailian-trial/help.html">完整说明与实际验证范围</a></p>`;
await writeFile(join(directory,'开始使用.html'),guide);await cp(join(root,'docs/THIRD_PARTY.md'),join(directory,'开源组件说明.md'));
console.log(JSON.stringify({directory,platform,arch,version:pkg.version,preview:true,notarized:false}));
